gdjs.HomeCode = {};
gdjs.HomeCode.GDTitleTextObjects1= [];
gdjs.HomeCode.GDTitleTextObjects2= [];
gdjs.HomeCode.GDBackTextObjects1= [];
gdjs.HomeCode.GDBackTextObjects2= [];
gdjs.HomeCode.GDPlayTextObjects1= [];
gdjs.HomeCode.GDPlayTextObjects2= [];
gdjs.HomeCode.GDOptionsTextObjects1= [];
gdjs.HomeCode.GDOptionsTextObjects2= [];
gdjs.HomeCode.GDQuitTextObjects1= [];
gdjs.HomeCode.GDQuitTextObjects2= [];
gdjs.HomeCode.GDWTextObjects1= [];
gdjs.HomeCode.GDWTextObjects2= [];
gdjs.HomeCode.GDSoundTextObjects1= [];
gdjs.HomeCode.GDSoundTextObjects2= [];
gdjs.HomeCode.GDSwitchWObjects1= [];
gdjs.HomeCode.GDSwitchWObjects2= [];
gdjs.HomeCode.GDSwitchSoundObjects1= [];
gdjs.HomeCode.GDSwitchSoundObjects2= [];
gdjs.HomeCode.GDBnuuyObjects1= [];
gdjs.HomeCode.GDBnuuyObjects2= [];
gdjs.HomeCode.GDseaObjects1= [];
gdjs.HomeCode.GDseaObjects2= [];
gdjs.HomeCode.GDGrassObjects1= [];
gdjs.HomeCode.GDGrassObjects2= [];
gdjs.HomeCode.GDDirtObjects1= [];
gdjs.HomeCode.GDDirtObjects2= [];
gdjs.HomeCode.GDInvisWallObjects1= [];
gdjs.HomeCode.GDInvisWallObjects2= [];
gdjs.HomeCode.GDInvisWall2Objects1= [];
gdjs.HomeCode.GDInvisWall2Objects2= [];
gdjs.HomeCode.GDDashParticleObjects1= [];
gdjs.HomeCode.GDDashParticleObjects2= [];
gdjs.HomeCode.GDLandParticlesObjects1= [];
gdjs.HomeCode.GDLandParticlesObjects2= [];
gdjs.HomeCode.GDLandParticles3Objects1= [];
gdjs.HomeCode.GDLandParticles3Objects2= [];
gdjs.HomeCode.GDLandParticles2Objects1= [];
gdjs.HomeCode.GDLandParticles2Objects2= [];
gdjs.HomeCode.GDCarrotObjects1= [];
gdjs.HomeCode.GDCarrotObjects2= [];
gdjs.HomeCode.GDSadBNUUYObjects1= [];
gdjs.HomeCode.GDSadBNUUYObjects2= [];
gdjs.HomeCode.GDDebuggerTextObjects1= [];
gdjs.HomeCode.GDDebuggerTextObjects2= [];
gdjs.HomeCode.GDBnuuyDashAfterLeftObjects1= [];
gdjs.HomeCode.GDBnuuyDashAfterLeftObjects2= [];
gdjs.HomeCode.GDLandParticles4Objects1= [];
gdjs.HomeCode.GDLandParticles4Objects2= [];
gdjs.HomeCode.GDSawbladeObjects1= [];
gdjs.HomeCode.GDSawbladeObjects2= [];
gdjs.HomeCode.GDDeathObjects1= [];
gdjs.HomeCode.GDDeathObjects2= [];
gdjs.HomeCode.GDDeathLeftObjects1= [];
gdjs.HomeCode.GDDeathLeftObjects2= [];
gdjs.HomeCode.GDFoxObjects1= [];
gdjs.HomeCode.GDFoxObjects2= [];
gdjs.HomeCode.GDOrbObjects1= [];
gdjs.HomeCode.GDOrbObjects2= [];
gdjs.HomeCode.GDArrowObjects1= [];
gdjs.HomeCode.GDArrowObjects2= [];
gdjs.HomeCode.GDDirtHalfObjects1= [];
gdjs.HomeCode.GDDirtHalfObjects2= [];
gdjs.HomeCode.GDSawbladeUpDownObjects1= [];
gdjs.HomeCode.GDSawbladeUpDownObjects2= [];
gdjs.HomeCode.GDSawbladeLeftRightObjects1= [];
gdjs.HomeCode.GDSawbladeLeftRightObjects2= [];
gdjs.HomeCode.GDJumpthruObjects1= [];
gdjs.HomeCode.GDJumpthruObjects2= [];
gdjs.HomeCode.GDDoubleOrbObjects1= [];
gdjs.HomeCode.GDDoubleOrbObjects2= [];
gdjs.HomeCode.GDOrbSpawnerObjects1= [];
gdjs.HomeCode.GDOrbSpawnerObjects2= [];


gdjs.HomeCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SwitchW"), gdjs.HomeCode.GDSwitchWObjects1);
{for(var i = 0, len = gdjs.HomeCode.GDSwitchWObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDSwitchWObjects1[i].SetChecked(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.HomeCode.GDSwitchWObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDSwitchWObjects1[i].SetChecked(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayText"), gdjs.HomeCode.GDPlayTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDPlayTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDPlayTextObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDPlayTextObjects1[k] = gdjs.HomeCode.GDPlayTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDPlayTextObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("QuitText"), gdjs.HomeCode.GDQuitTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDQuitTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDQuitTextObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDQuitTextObjects1[k] = gdjs.HomeCode.GDQuitTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDQuitTextObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionsText"), gdjs.HomeCode.GDOptionsTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDOptionsTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDOptionsTextObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDOptionsTextObjects1[k] = gdjs.HomeCode.GDOptionsTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDOptionsTextObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("InvisWall2"), gdjs.HomeCode.GDInvisWall2Objects1);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "BigCam", (( gdjs.HomeCode.GDInvisWall2Objects1.length === 0 ) ? 0 :gdjs.HomeCode.GDInvisWall2Objects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", 1000, "easeInOutQuad");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackText"), gdjs.HomeCode.GDBackTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDBackTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDBackTextObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDBackTextObjects1[k] = gdjs.HomeCode.GDBackTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDBackTextObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("InvisWall"), gdjs.HomeCode.GDInvisWallObjects1);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "BigCam", (( gdjs.HomeCode.GDInvisWallObjects1.length === 0 ) ? 0 :gdjs.HomeCode.GDInvisWallObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", 1000, "easeInOutQuad");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayText"), gdjs.HomeCode.GDPlayTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDPlayTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDPlayTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDPlayTextObjects1[k] = gdjs.HomeCode.GDPlayTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDPlayTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDPlayTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDPlayTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDPlayTextObjects1[i].getBehavior("Tween").addObjectScaleTween("BigBoy", 1.5, 1.5, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("QuitText"), gdjs.HomeCode.GDQuitTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDQuitTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDQuitTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDQuitTextObjects1[k] = gdjs.HomeCode.GDQuitTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDQuitTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDQuitTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDQuitTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDQuitTextObjects1[i].getBehavior("Tween").addObjectScaleTween("BigBoy", 1.5, 1.5, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionsText"), gdjs.HomeCode.GDOptionsTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDOptionsTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDOptionsTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDOptionsTextObjects1[k] = gdjs.HomeCode.GDOptionsTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDOptionsTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDOptionsTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDOptionsTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDOptionsTextObjects1[i].getBehavior("Tween").addObjectScaleTween("BigBoy", 1.5, 1.5, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackText"), gdjs.HomeCode.GDBackTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDBackTextObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDBackTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDBackTextObjects1[k] = gdjs.HomeCode.GDBackTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDBackTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDBackTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDBackTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDBackTextObjects1[i].getBehavior("Tween").addObjectScaleTween("SmolBoy", 1.5, 1.5, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PlayText"), gdjs.HomeCode.GDPlayTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDPlayTextObjects1.length;i<l;++i) {
    if ( !(gdjs.HomeCode.GDPlayTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDPlayTextObjects1[k] = gdjs.HomeCode.GDPlayTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDPlayTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDPlayTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDPlayTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDPlayTextObjects1[i].getBehavior("Tween").addObjectScaleTween("SmolBoy", 1, 1, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("QuitText"), gdjs.HomeCode.GDQuitTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDQuitTextObjects1.length;i<l;++i) {
    if ( !(gdjs.HomeCode.GDQuitTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDQuitTextObjects1[k] = gdjs.HomeCode.GDQuitTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDQuitTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDQuitTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDQuitTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDQuitTextObjects1[i].getBehavior("Tween").addObjectScaleTween("SmolBoy", 1, 1, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OptionsText"), gdjs.HomeCode.GDOptionsTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDOptionsTextObjects1.length;i<l;++i) {
    if ( !(gdjs.HomeCode.GDOptionsTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDOptionsTextObjects1[k] = gdjs.HomeCode.GDOptionsTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDOptionsTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDOptionsTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDOptionsTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDOptionsTextObjects1[i].getBehavior("Tween").addObjectScaleTween("SmolBoy", 1, 1, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackText"), gdjs.HomeCode.GDBackTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDBackTextObjects1.length;i<l;++i) {
    if ( !(gdjs.HomeCode.GDBackTextObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDBackTextObjects1[k] = gdjs.HomeCode.GDBackTextObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDBackTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.HomeCode.GDBackTextObjects1 */
{for(var i = 0, len = gdjs.HomeCode.GDBackTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDBackTextObjects1[i].getBehavior("Tween").addObjectScaleTween("SmolBoy", 1, 1, "linear", 300, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SwitchW"), gdjs.HomeCode.GDSwitchWObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDSwitchWObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDSwitchWObjects1[i].HasJustBeenChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDSwitchWObjects1[k] = gdjs.HomeCode.GDSwitchWObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDSwitchWObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SwitchW"), gdjs.HomeCode.GDSwitchWObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.HomeCode.GDSwitchWObjects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDSwitchWObjects1[i].HasJustBeenUnchecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.HomeCode.GDSwitchWObjects1[k] = gdjs.HomeCode.GDSwitchWObjects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDSwitchWObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), false);
}}

}


};

gdjs.HomeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HomeCode.GDTitleTextObjects1.length = 0;
gdjs.HomeCode.GDTitleTextObjects2.length = 0;
gdjs.HomeCode.GDBackTextObjects1.length = 0;
gdjs.HomeCode.GDBackTextObjects2.length = 0;
gdjs.HomeCode.GDPlayTextObjects1.length = 0;
gdjs.HomeCode.GDPlayTextObjects2.length = 0;
gdjs.HomeCode.GDOptionsTextObjects1.length = 0;
gdjs.HomeCode.GDOptionsTextObjects2.length = 0;
gdjs.HomeCode.GDQuitTextObjects1.length = 0;
gdjs.HomeCode.GDQuitTextObjects2.length = 0;
gdjs.HomeCode.GDWTextObjects1.length = 0;
gdjs.HomeCode.GDWTextObjects2.length = 0;
gdjs.HomeCode.GDSoundTextObjects1.length = 0;
gdjs.HomeCode.GDSoundTextObjects2.length = 0;
gdjs.HomeCode.GDSwitchWObjects1.length = 0;
gdjs.HomeCode.GDSwitchWObjects2.length = 0;
gdjs.HomeCode.GDSwitchSoundObjects1.length = 0;
gdjs.HomeCode.GDSwitchSoundObjects2.length = 0;
gdjs.HomeCode.GDBnuuyObjects1.length = 0;
gdjs.HomeCode.GDBnuuyObjects2.length = 0;
gdjs.HomeCode.GDseaObjects1.length = 0;
gdjs.HomeCode.GDseaObjects2.length = 0;
gdjs.HomeCode.GDGrassObjects1.length = 0;
gdjs.HomeCode.GDGrassObjects2.length = 0;
gdjs.HomeCode.GDDirtObjects1.length = 0;
gdjs.HomeCode.GDDirtObjects2.length = 0;
gdjs.HomeCode.GDInvisWallObjects1.length = 0;
gdjs.HomeCode.GDInvisWallObjects2.length = 0;
gdjs.HomeCode.GDInvisWall2Objects1.length = 0;
gdjs.HomeCode.GDInvisWall2Objects2.length = 0;
gdjs.HomeCode.GDDashParticleObjects1.length = 0;
gdjs.HomeCode.GDDashParticleObjects2.length = 0;
gdjs.HomeCode.GDLandParticlesObjects1.length = 0;
gdjs.HomeCode.GDLandParticlesObjects2.length = 0;
gdjs.HomeCode.GDLandParticles3Objects1.length = 0;
gdjs.HomeCode.GDLandParticles3Objects2.length = 0;
gdjs.HomeCode.GDLandParticles2Objects1.length = 0;
gdjs.HomeCode.GDLandParticles2Objects2.length = 0;
gdjs.HomeCode.GDCarrotObjects1.length = 0;
gdjs.HomeCode.GDCarrotObjects2.length = 0;
gdjs.HomeCode.GDSadBNUUYObjects1.length = 0;
gdjs.HomeCode.GDSadBNUUYObjects2.length = 0;
gdjs.HomeCode.GDDebuggerTextObjects1.length = 0;
gdjs.HomeCode.GDDebuggerTextObjects2.length = 0;
gdjs.HomeCode.GDBnuuyDashAfterLeftObjects1.length = 0;
gdjs.HomeCode.GDBnuuyDashAfterLeftObjects2.length = 0;
gdjs.HomeCode.GDLandParticles4Objects1.length = 0;
gdjs.HomeCode.GDLandParticles4Objects2.length = 0;
gdjs.HomeCode.GDSawbladeObjects1.length = 0;
gdjs.HomeCode.GDSawbladeObjects2.length = 0;
gdjs.HomeCode.GDDeathObjects1.length = 0;
gdjs.HomeCode.GDDeathObjects2.length = 0;
gdjs.HomeCode.GDDeathLeftObjects1.length = 0;
gdjs.HomeCode.GDDeathLeftObjects2.length = 0;
gdjs.HomeCode.GDFoxObjects1.length = 0;
gdjs.HomeCode.GDFoxObjects2.length = 0;
gdjs.HomeCode.GDOrbObjects1.length = 0;
gdjs.HomeCode.GDOrbObjects2.length = 0;
gdjs.HomeCode.GDArrowObjects1.length = 0;
gdjs.HomeCode.GDArrowObjects2.length = 0;
gdjs.HomeCode.GDDirtHalfObjects1.length = 0;
gdjs.HomeCode.GDDirtHalfObjects2.length = 0;
gdjs.HomeCode.GDSawbladeUpDownObjects1.length = 0;
gdjs.HomeCode.GDSawbladeUpDownObjects2.length = 0;
gdjs.HomeCode.GDSawbladeLeftRightObjects1.length = 0;
gdjs.HomeCode.GDSawbladeLeftRightObjects2.length = 0;
gdjs.HomeCode.GDJumpthruObjects1.length = 0;
gdjs.HomeCode.GDJumpthruObjects2.length = 0;
gdjs.HomeCode.GDDoubleOrbObjects1.length = 0;
gdjs.HomeCode.GDDoubleOrbObjects2.length = 0;
gdjs.HomeCode.GDOrbSpawnerObjects1.length = 0;
gdjs.HomeCode.GDOrbSpawnerObjects2.length = 0;

gdjs.HomeCode.eventsList0(runtimeScene);

return;

}

gdjs['HomeCode'] = gdjs.HomeCode;
