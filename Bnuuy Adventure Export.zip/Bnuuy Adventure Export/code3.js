gdjs.Level3Code = {};
gdjs.Level3Code.GDBnuuyObjects1= [];
gdjs.Level3Code.GDBnuuyObjects2= [];
gdjs.Level3Code.GDBnuuyObjects3= [];
gdjs.Level3Code.GDBnuuyObjects4= [];
gdjs.Level3Code.GDBnuuyObjects5= [];
gdjs.Level3Code.GDBnuuyObjects6= [];
gdjs.Level3Code.GDBnuuyObjects7= [];
gdjs.Level3Code.GDBnuuyObjects8= [];
gdjs.Level3Code.GDseaObjects1= [];
gdjs.Level3Code.GDseaObjects2= [];
gdjs.Level3Code.GDseaObjects3= [];
gdjs.Level3Code.GDseaObjects4= [];
gdjs.Level3Code.GDseaObjects5= [];
gdjs.Level3Code.GDseaObjects6= [];
gdjs.Level3Code.GDseaObjects7= [];
gdjs.Level3Code.GDseaObjects8= [];
gdjs.Level3Code.GDGrassObjects1= [];
gdjs.Level3Code.GDGrassObjects2= [];
gdjs.Level3Code.GDGrassObjects3= [];
gdjs.Level3Code.GDGrassObjects4= [];
gdjs.Level3Code.GDGrassObjects5= [];
gdjs.Level3Code.GDGrassObjects6= [];
gdjs.Level3Code.GDGrassObjects7= [];
gdjs.Level3Code.GDGrassObjects8= [];
gdjs.Level3Code.GDDirtObjects1= [];
gdjs.Level3Code.GDDirtObjects2= [];
gdjs.Level3Code.GDDirtObjects3= [];
gdjs.Level3Code.GDDirtObjects4= [];
gdjs.Level3Code.GDDirtObjects5= [];
gdjs.Level3Code.GDDirtObjects6= [];
gdjs.Level3Code.GDDirtObjects7= [];
gdjs.Level3Code.GDDirtObjects8= [];
gdjs.Level3Code.GDInvisWallObjects1= [];
gdjs.Level3Code.GDInvisWallObjects2= [];
gdjs.Level3Code.GDInvisWallObjects3= [];
gdjs.Level3Code.GDInvisWallObjects4= [];
gdjs.Level3Code.GDInvisWallObjects5= [];
gdjs.Level3Code.GDInvisWallObjects6= [];
gdjs.Level3Code.GDInvisWallObjects7= [];
gdjs.Level3Code.GDInvisWallObjects8= [];
gdjs.Level3Code.GDInvisWall2Objects1= [];
gdjs.Level3Code.GDInvisWall2Objects2= [];
gdjs.Level3Code.GDInvisWall2Objects3= [];
gdjs.Level3Code.GDInvisWall2Objects4= [];
gdjs.Level3Code.GDInvisWall2Objects5= [];
gdjs.Level3Code.GDInvisWall2Objects6= [];
gdjs.Level3Code.GDInvisWall2Objects7= [];
gdjs.Level3Code.GDInvisWall2Objects8= [];
gdjs.Level3Code.GDDashParticleObjects1= [];
gdjs.Level3Code.GDDashParticleObjects2= [];
gdjs.Level3Code.GDDashParticleObjects3= [];
gdjs.Level3Code.GDDashParticleObjects4= [];
gdjs.Level3Code.GDDashParticleObjects5= [];
gdjs.Level3Code.GDDashParticleObjects6= [];
gdjs.Level3Code.GDDashParticleObjects7= [];
gdjs.Level3Code.GDDashParticleObjects8= [];
gdjs.Level3Code.GDLandParticlesObjects1= [];
gdjs.Level3Code.GDLandParticlesObjects2= [];
gdjs.Level3Code.GDLandParticlesObjects3= [];
gdjs.Level3Code.GDLandParticlesObjects4= [];
gdjs.Level3Code.GDLandParticlesObjects5= [];
gdjs.Level3Code.GDLandParticlesObjects6= [];
gdjs.Level3Code.GDLandParticlesObjects7= [];
gdjs.Level3Code.GDLandParticlesObjects8= [];
gdjs.Level3Code.GDLandParticles3Objects1= [];
gdjs.Level3Code.GDLandParticles3Objects2= [];
gdjs.Level3Code.GDLandParticles3Objects3= [];
gdjs.Level3Code.GDLandParticles3Objects4= [];
gdjs.Level3Code.GDLandParticles3Objects5= [];
gdjs.Level3Code.GDLandParticles3Objects6= [];
gdjs.Level3Code.GDLandParticles3Objects7= [];
gdjs.Level3Code.GDLandParticles3Objects8= [];
gdjs.Level3Code.GDLandParticles2Objects1= [];
gdjs.Level3Code.GDLandParticles2Objects2= [];
gdjs.Level3Code.GDLandParticles2Objects3= [];
gdjs.Level3Code.GDLandParticles2Objects4= [];
gdjs.Level3Code.GDLandParticles2Objects5= [];
gdjs.Level3Code.GDLandParticles2Objects6= [];
gdjs.Level3Code.GDLandParticles2Objects7= [];
gdjs.Level3Code.GDLandParticles2Objects8= [];
gdjs.Level3Code.GDCarrotObjects1= [];
gdjs.Level3Code.GDCarrotObjects2= [];
gdjs.Level3Code.GDCarrotObjects3= [];
gdjs.Level3Code.GDCarrotObjects4= [];
gdjs.Level3Code.GDCarrotObjects5= [];
gdjs.Level3Code.GDCarrotObjects6= [];
gdjs.Level3Code.GDCarrotObjects7= [];
gdjs.Level3Code.GDCarrotObjects8= [];
gdjs.Level3Code.GDSadBNUUYObjects1= [];
gdjs.Level3Code.GDSadBNUUYObjects2= [];
gdjs.Level3Code.GDSadBNUUYObjects3= [];
gdjs.Level3Code.GDSadBNUUYObjects4= [];
gdjs.Level3Code.GDSadBNUUYObjects5= [];
gdjs.Level3Code.GDSadBNUUYObjects6= [];
gdjs.Level3Code.GDSadBNUUYObjects7= [];
gdjs.Level3Code.GDSadBNUUYObjects8= [];
gdjs.Level3Code.GDDebuggerTextObjects1= [];
gdjs.Level3Code.GDDebuggerTextObjects2= [];
gdjs.Level3Code.GDDebuggerTextObjects3= [];
gdjs.Level3Code.GDDebuggerTextObjects4= [];
gdjs.Level3Code.GDDebuggerTextObjects5= [];
gdjs.Level3Code.GDDebuggerTextObjects6= [];
gdjs.Level3Code.GDDebuggerTextObjects7= [];
gdjs.Level3Code.GDDebuggerTextObjects8= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects1= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects2= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects3= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects4= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects5= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects6= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7= [];
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects8= [];
gdjs.Level3Code.GDLandParticles4Objects1= [];
gdjs.Level3Code.GDLandParticles4Objects2= [];
gdjs.Level3Code.GDLandParticles4Objects3= [];
gdjs.Level3Code.GDLandParticles4Objects4= [];
gdjs.Level3Code.GDLandParticles4Objects5= [];
gdjs.Level3Code.GDLandParticles4Objects6= [];
gdjs.Level3Code.GDLandParticles4Objects7= [];
gdjs.Level3Code.GDLandParticles4Objects8= [];
gdjs.Level3Code.GDSawbladeObjects1= [];
gdjs.Level3Code.GDSawbladeObjects2= [];
gdjs.Level3Code.GDSawbladeObjects3= [];
gdjs.Level3Code.GDSawbladeObjects4= [];
gdjs.Level3Code.GDSawbladeObjects5= [];
gdjs.Level3Code.GDSawbladeObjects6= [];
gdjs.Level3Code.GDSawbladeObjects7= [];
gdjs.Level3Code.GDSawbladeObjects8= [];
gdjs.Level3Code.GDDeathObjects1= [];
gdjs.Level3Code.GDDeathObjects2= [];
gdjs.Level3Code.GDDeathObjects3= [];
gdjs.Level3Code.GDDeathObjects4= [];
gdjs.Level3Code.GDDeathObjects5= [];
gdjs.Level3Code.GDDeathObjects6= [];
gdjs.Level3Code.GDDeathObjects7= [];
gdjs.Level3Code.GDDeathObjects8= [];
gdjs.Level3Code.GDDeathLeftObjects1= [];
gdjs.Level3Code.GDDeathLeftObjects2= [];
gdjs.Level3Code.GDDeathLeftObjects3= [];
gdjs.Level3Code.GDDeathLeftObjects4= [];
gdjs.Level3Code.GDDeathLeftObjects5= [];
gdjs.Level3Code.GDDeathLeftObjects6= [];
gdjs.Level3Code.GDDeathLeftObjects7= [];
gdjs.Level3Code.GDDeathLeftObjects8= [];
gdjs.Level3Code.GDFoxObjects1= [];
gdjs.Level3Code.GDFoxObjects2= [];
gdjs.Level3Code.GDFoxObjects3= [];
gdjs.Level3Code.GDFoxObjects4= [];
gdjs.Level3Code.GDFoxObjects5= [];
gdjs.Level3Code.GDFoxObjects6= [];
gdjs.Level3Code.GDFoxObjects7= [];
gdjs.Level3Code.GDFoxObjects8= [];
gdjs.Level3Code.GDOrbObjects1= [];
gdjs.Level3Code.GDOrbObjects2= [];
gdjs.Level3Code.GDOrbObjects3= [];
gdjs.Level3Code.GDOrbObjects4= [];
gdjs.Level3Code.GDOrbObjects5= [];
gdjs.Level3Code.GDOrbObjects6= [];
gdjs.Level3Code.GDOrbObjects7= [];
gdjs.Level3Code.GDOrbObjects8= [];
gdjs.Level3Code.GDArrowObjects1= [];
gdjs.Level3Code.GDArrowObjects2= [];
gdjs.Level3Code.GDArrowObjects3= [];
gdjs.Level3Code.GDArrowObjects4= [];
gdjs.Level3Code.GDArrowObjects5= [];
gdjs.Level3Code.GDArrowObjects6= [];
gdjs.Level3Code.GDArrowObjects7= [];
gdjs.Level3Code.GDArrowObjects8= [];
gdjs.Level3Code.GDDirtHalfObjects1= [];
gdjs.Level3Code.GDDirtHalfObjects2= [];
gdjs.Level3Code.GDDirtHalfObjects3= [];
gdjs.Level3Code.GDDirtHalfObjects4= [];
gdjs.Level3Code.GDDirtHalfObjects5= [];
gdjs.Level3Code.GDDirtHalfObjects6= [];
gdjs.Level3Code.GDDirtHalfObjects7= [];
gdjs.Level3Code.GDDirtHalfObjects8= [];
gdjs.Level3Code.GDSawbladeUpDownObjects1= [];
gdjs.Level3Code.GDSawbladeUpDownObjects2= [];
gdjs.Level3Code.GDSawbladeUpDownObjects3= [];
gdjs.Level3Code.GDSawbladeUpDownObjects4= [];
gdjs.Level3Code.GDSawbladeUpDownObjects5= [];
gdjs.Level3Code.GDSawbladeUpDownObjects6= [];
gdjs.Level3Code.GDSawbladeUpDownObjects7= [];
gdjs.Level3Code.GDSawbladeUpDownObjects8= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects1= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects2= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects3= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects4= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects5= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects6= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects7= [];
gdjs.Level3Code.GDSawbladeLeftRightObjects8= [];
gdjs.Level3Code.GDJumpthruObjects1= [];
gdjs.Level3Code.GDJumpthruObjects2= [];
gdjs.Level3Code.GDJumpthruObjects3= [];
gdjs.Level3Code.GDJumpthruObjects4= [];
gdjs.Level3Code.GDJumpthruObjects5= [];
gdjs.Level3Code.GDJumpthruObjects6= [];
gdjs.Level3Code.GDJumpthruObjects7= [];
gdjs.Level3Code.GDJumpthruObjects8= [];
gdjs.Level3Code.GDDoubleOrbObjects1= [];
gdjs.Level3Code.GDDoubleOrbObjects2= [];
gdjs.Level3Code.GDDoubleOrbObjects3= [];
gdjs.Level3Code.GDDoubleOrbObjects4= [];
gdjs.Level3Code.GDDoubleOrbObjects5= [];
gdjs.Level3Code.GDDoubleOrbObjects6= [];
gdjs.Level3Code.GDDoubleOrbObjects7= [];
gdjs.Level3Code.GDDoubleOrbObjects8= [];
gdjs.Level3Code.GDOrbSpawnerObjects1= [];
gdjs.Level3Code.GDOrbSpawnerObjects2= [];
gdjs.Level3Code.GDOrbSpawnerObjects3= [];
gdjs.Level3Code.GDOrbSpawnerObjects4= [];
gdjs.Level3Code.GDOrbSpawnerObjects5= [];
gdjs.Level3Code.GDOrbSpawnerObjects6= [];
gdjs.Level3Code.GDOrbSpawnerObjects7= [];
gdjs.Level3Code.GDOrbSpawnerObjects8= [];


gdjs.Level3Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.Level3Code.GDArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carrot"), gdjs.Level3Code.GDCarrotObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dirt"), gdjs.Level3Code.GDDirtObjects1);
gdjs.copyArray(runtimeScene.getObjects("DoubleOrb"), gdjs.Level3Code.GDDoubleOrbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Grass"), gdjs.Level3Code.GDGrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("Orb"), gdjs.Level3Code.GDOrbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sawblade"), gdjs.Level3Code.GDSawbladeObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeLeftRight"), gdjs.Level3Code.GDSawbladeLeftRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeUpDown"), gdjs.Level3Code.GDSawbladeUpDownObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDCarrotObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDCarrotObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{}{}{for(var i = 0, len = gdjs.Level3Code.GDArrowObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDArrowObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDOrbObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDOrbObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 6, 6, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDOrbObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDOrbObjects1[i].getBehavior("Tween").addObjectOpacityTween("Opacity", 140, "easeInOutQuad", 200, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDSawbladeObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 8, 8, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDSawbladeUpDownObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeUpDownObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 8, 8, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDSawbladeLeftRightObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeLeftRightObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 8, 8, "elastic", 50, false, true);
}
}{runtimeScene.getGame().getVariables().get("Bruh").setString("Right");
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(1);
}{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects1[i].returnVariable(gdjs.Level3Code.GDFoxObjects1[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber((( gdjs.Level3Code.GDDoubleOrbObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDDoubleOrbObjects1[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber((( gdjs.Level3Code.GDDoubleOrbObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDDoubleOrbObjects1[0].getPointX("")));
}{for(var i = 0, len = gdjs.Level3Code.GDSawbladeObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeObjects1[i].setZOrder(220);
}
}{for(var i = 0, len = gdjs.Level3Code.GDSawbladeUpDownObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeUpDownObjects1[i].setZOrder(220);
}
}{for(var i = 0, len = gdjs.Level3Code.GDSawbladeLeftRightObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeLeftRightObjects1[i].setZOrder(220);
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects3Objects = Hashtable.newFrom({"SadBNUUY": gdjs.Level3Code.GDSadBNUUYObjects3});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects4Objects = Hashtable.newFrom({"SadBNUUY": gdjs.Level3Code.GDSadBNUUYObjects4});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects5Objects = Hashtable.newFrom({"SadBNUUY": gdjs.Level3Code.GDSadBNUUYObjects5});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects6Objects = Hashtable.newFrom({"SadBNUUY": gdjs.Level3Code.GDSadBNUUYObjects6});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects7Objects = Hashtable.newFrom({"SadBNUUY": gdjs.Level3Code.GDSadBNUUYObjects7});
gdjs.Level3Code.asyncCallback17048756 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.Level3Code.GDSadBNUUYObjects8);

{for(var i = 0, len = gdjs.Level3Code.GDSadBNUUYObjects8.length ;i < len;++i) {
    gdjs.Level3Code.GDSadBNUUYObjects8[i].getBehavior("Tween").addObjectScaleTween("ByeBnuuy", 0.6, 0.6, "easeInOutQuad", 400, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDSadBNUUYObjects8.length ;i < len;++i) {
    gdjs.Level3Code.GDSadBNUUYObjects8[i].getBehavior("Tween").addObjectOpacityTween("Dissapear", 0, "easeOutQuart", 400, true);
}
}}
gdjs.Level3Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDSadBNUUYObjects7) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.05), (runtimeScene) => (gdjs.Level3Code.asyncCallback17048756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17047772 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects7);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.Level3Code.GDSadBNUUYObjects7);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects7Objects, (( gdjs.Level3Code.GDBnuuyObjects7.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects7[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects7.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects7[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyObjects6) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDSadBNUUYObjects6) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17047772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17048132 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects6);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.Level3Code.GDSadBNUUYObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects6Objects, (( gdjs.Level3Code.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects6[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects6[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyObjects5) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDSadBNUUYObjects5) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17048132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17047140 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.Level3Code.GDSadBNUUYObjects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects5Objects, (( gdjs.Level3Code.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects5[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects5[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyObjects4) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDSadBNUUYObjects4) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17047140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17047044 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.Level3Code.GDSadBNUUYObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects4Objects, (( gdjs.Level3Code.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects4[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects4[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level3Code.GDBnuuyObjects3) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDSadBNUUYObjects3) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17047044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects2Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.Level3Code.GDBnuuyDashAfterLeftObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects3Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.Level3Code.GDBnuuyDashAfterLeftObjects3});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects4Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.Level3Code.GDBnuuyDashAfterLeftObjects4});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects5Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.Level3Code.GDBnuuyDashAfterLeftObjects5});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects6Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.Level3Code.GDBnuuyDashAfterLeftObjects6});
gdjs.Level3Code.asyncCallback17051852 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7);

{for(var i = 0, len = gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7[i].getBehavior("Tween").addObjectScaleTween("ByeBnuuyLeft", 0.6, 0.6, "easeInOutQuad", 400, false, true);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7[i].getBehavior("Tween").addObjectOpacityTween("DissapearLeft", 0, "easeOutQuart", 400, true);
}
}}
gdjs.Level3Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyDashAfterLeftObjects6) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.05), (runtimeScene) => (gdjs.Level3Code.asyncCallback17051852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17051924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects6);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.Level3Code.GDBnuuyDashAfterLeftObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects6Objects, (( gdjs.Level3Code.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects6[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects6[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyObjects5) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDBnuuyDashAfterLeftObjects5) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17051924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17051540 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.Level3Code.GDBnuuyDashAfterLeftObjects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects5Objects, (( gdjs.Level3Code.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects5[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects5[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyObjects4) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDBnuuyDashAfterLeftObjects4) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17051540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17049924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.Level3Code.GDBnuuyDashAfterLeftObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects4Objects, (( gdjs.Level3Code.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects4[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects4[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDBnuuyObjects3) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDBnuuyDashAfterLeftObjects3) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17049924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17049188 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.Level3Code.GDBnuuyDashAfterLeftObjects3);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects3Objects, (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level3Code.GDBnuuyObjects2) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.Level3Code.GDBnuuyDashAfterLeftObjects2) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback17049188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDBnuuyObjects2, gdjs.Level3Code.GDBnuuyObjects3);

gdjs.Level3Code.GDSadBNUUYObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSadBNUUYObjects3Objects, (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects2 */
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyDashAfterLeftObjects2Objects, (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.Level3Code.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDBnuuyObjects2, gdjs.Level3Code.GDBnuuyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects3.length;i<l;++i) {
    if ( gdjs.Level3Code.GDBnuuyObjects3[i].getVariableNumber(gdjs.Level3Code.GDBnuuyObjects3[i].getVariables().getFromIndex(0)) == -(10) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects3[k] = gdjs.Level3Code.GDBnuuyObjects3[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects3 */
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].returnVariable(gdjs.Level3Code.GDBnuuyObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


{

/* Reuse gdjs.Level3Code.GDBnuuyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDBnuuyObjects2[i].getVariableNumber(gdjs.Level3Code.GDBnuuyObjects2[i].getVariables().getFromIndex(0)) == 10 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects2[k] = gdjs.Level3Code.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].returnVariable(gdjs.Level3Code.GDBnuuyObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.Level3Code.asyncCallback17061628 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects3);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].returnVariable(gdjs.Level3Code.GDBnuuyObjects3[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}}
gdjs.Level3Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level3Code.asyncCallback17061628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17063076 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects3);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].returnVariable(gdjs.Level3Code.GDBnuuyObjects3[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}}
gdjs.Level3Code.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level3Code.asyncCallback17063076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17064220 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].returnVariable(gdjs.Level3Code.GDBnuuyObjects2[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}}
gdjs.Level3Code.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level3Code.asyncCallback17064220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects2[k] = gdjs.Level3Code.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17045420);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "a54eee0a33e2249eb99f672c676f5c643369128d38b234af317fd5677a26ec70_Jump_Start_01.wav", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("HorizontalDash").IsDashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects2[k] = gdjs.Level3Code.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17046740);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "24911cec3e29b654a6e4bdd454756546c5492abdfc4f7f0ecc4cffebee5171d6_Hard_Run_06.wav", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}
{ //Subevents
gdjs.Level3Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects2[k] = gdjs.Level3Code.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17057828);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].returnVariable(gdjs.Level3Code.GDBnuuyObjects2[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects2.length;i<l;++i) {
    if ( !(gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects2[k] = gdjs.Level3Code.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17059308);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 2;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects2.length;i<l;++i) {
    if ( !(gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects2[k] = gdjs.Level3Code.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DebuggerText"), gdjs.Level3Code.GDDebuggerTextObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDDebuggerTextObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDebuggerTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDBnuuyObjects1.length;i<l;++i) {
    if ( gdjs.Level3Code.GDBnuuyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDBnuuyObjects1[k] = gdjs.Level3Code.GDBnuuyObjects1[i];
        ++k;
    }
}
gdjs.Level3Code.GDBnuuyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DebuggerText"), gdjs.Level3Code.GDDebuggerTextObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDDebuggerTextObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDebuggerTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")));
}
}}

}


};gdjs.Level3Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{runtimeScene.getGame().getVariables().get("Bruh").setString("Right");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{runtimeScene.getGame().getVariables().get("Bruh").setString("Left");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "j");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "B", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "X", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.Level3Code.GDBnuuyObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSawbladeObjects1Objects = Hashtable.newFrom({"Sawblade": gdjs.Level3Code.GDSawbladeObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects2Objects = Hashtable.newFrom({"Death": gdjs.Level3Code.GDDeathObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects1Objects = Hashtable.newFrom({"DeathLeft": gdjs.Level3Code.GDDeathLeftObjects1});
gdjs.Level3Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDBnuuyObjects1, gdjs.Level3Code.GDBnuuyObjects2);

gdjs.Level3Code.GDDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects2Objects, (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects1 */
gdjs.Level3Code.GDDeathLeftObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects1Objects, (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level3Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sawblade"), gdjs.Level3Code.GDSawbladeObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDSawbladeObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeObjects2[i].rotate(360, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sawblade"), gdjs.Level3Code.GDSawbladeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSawbladeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.Level3Code.GDBnuuyObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSawbladeUpDownObjects1Objects = Hashtable.newFrom({"SawbladeUpDown": gdjs.Level3Code.GDSawbladeUpDownObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects2Objects = Hashtable.newFrom({"Death": gdjs.Level3Code.GDDeathObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects1Objects = Hashtable.newFrom({"DeathLeft": gdjs.Level3Code.GDDeathLeftObjects1});
gdjs.Level3Code.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDBnuuyObjects1, gdjs.Level3Code.GDBnuuyObjects2);

gdjs.Level3Code.GDDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects2Objects, (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects1 */
gdjs.Level3Code.GDDeathLeftObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects1Objects, (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level3Code.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SawbladeUpDown"), gdjs.Level3Code.GDSawbladeUpDownObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDSawbladeUpDownObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeUpDownObjects2[i].rotate(360, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeUpDown"), gdjs.Level3Code.GDSawbladeUpDownObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSawbladeUpDownObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.Level3Code.GDBnuuyObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSawbladeLeftRightObjects1Objects = Hashtable.newFrom({"SawbladeLeftRight": gdjs.Level3Code.GDSawbladeLeftRightObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects2Objects = Hashtable.newFrom({"Death": gdjs.Level3Code.GDDeathObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects1Objects = Hashtable.newFrom({"DeathLeft": gdjs.Level3Code.GDDeathLeftObjects1});
gdjs.Level3Code.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDBnuuyObjects1, gdjs.Level3Code.GDBnuuyObjects2);

gdjs.Level3Code.GDDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects2Objects, (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects1 */
gdjs.Level3Code.GDDeathLeftObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects1Objects, (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects1[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level3Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SawbladeLeftRight"), gdjs.Level3Code.GDSawbladeLeftRightObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDSawbladeLeftRightObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSawbladeLeftRightObjects2[i].rotate(360, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeLeftRight"), gdjs.Level3Code.GDSawbladeLeftRightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSawbladeLeftRightObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects2Objects = Hashtable.newFrom({"Bnuuy": gdjs.Level3Code.GDBnuuyObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDFoxObjects2Objects = Hashtable.newFrom({"Fox": gdjs.Level3Code.GDFoxObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.Level3Code.GDDeathObjects3});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects2Objects = Hashtable.newFrom({"DeathLeft": gdjs.Level3Code.GDDeathLeftObjects2});
gdjs.Level3Code.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDBnuuyObjects2, gdjs.Level3Code.GDBnuuyObjects3);

gdjs.Level3Code.GDDeathObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathObjects3Objects, (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects3[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathObjects3[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects3[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects2 */
gdjs.Level3Code.GDDeathLeftObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDeathLeftObjects2Objects, (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDDeathLeftObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDeathLeftObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.Level3Code.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level3Code.asyncCallback17099228 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects3);
{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects3[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects3[i].returnVariable(gdjs.Level3Code.GDFoxObjects3[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(3);
}}
gdjs.Level3Code.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level3Code.asyncCallback17099228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback17100428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects2[i].returnVariable(gdjs.Level3Code.GDFoxObjects2[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(2);
}}
gdjs.Level3Code.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level3Code.asyncCallback17100428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDFoxObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDFoxObjects2[i].getBehavior("RectangleMovement").IsOnRight((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDFoxObjects2[k] = gdjs.Level3Code.GDFoxObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDFoxObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDFoxObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDFoxObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDFoxObjects2[i].getBehavior("RectangleMovement").IsOnLeft((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDFoxObjects2[k] = gdjs.Level3Code.GDFoxObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDFoxObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDFoxObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDFoxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RunTweenFox")) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.Level3Code.GDFoxObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDFoxObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDFoxObjects2[i].returnVariable(gdjs.Level3Code.GDFoxObjects2[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(2);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RunTweenFox")) == 2;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList26(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RunTweenFox")) == 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects2Objects = Hashtable.newFrom({"Bnuuy": gdjs.Level3Code.GDBnuuyObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDoubleOrbObjects2Objects = Hashtable.newFrom({"DoubleOrb": gdjs.Level3Code.GDDoubleOrbObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDoubleOrbObjects1Objects = Hashtable.newFrom({"DoubleOrb": gdjs.Level3Code.GDDoubleOrbObjects1});
gdjs.Level3Code.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("DoubleOrb"), gdjs.Level3Code.GDDoubleOrbObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDoubleOrbObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBnuuyObjects2 */
/* Reuse gdjs.Level3Code.GDDoubleOrbObjects2 */
gdjs.copyArray(runtimeScene.getObjects("OrbSpawner"), gdjs.Level3Code.GDOrbSpawnerObjects2);
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.5, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(1, 5, 5, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level3Code.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDBnuuyObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level3Code.GDDoubleOrbObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDoubleOrbObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDOrbSpawnerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDOrbSpawnerObjects2[i].resetTimer("Respawn");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OrbSpawner"), gdjs.Level3Code.GDOrbSpawnerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDOrbSpawnerObjects1.length;i<l;++i) {
    if ( gdjs.Level3Code.GDOrbSpawnerObjects1[i].getTimerElapsedTimeInSecondsOrNaN("Respawn") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDOrbSpawnerObjects1[k] = gdjs.Level3Code.GDOrbSpawnerObjects1[i];
        ++k;
    }
}
gdjs.Level3Code.GDOrbSpawnerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DoubleOrb"), gdjs.Level3Code.GDDoubleOrbObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDDoubleOrbObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDDoubleOrbObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDoubleOrbObjects1Objects, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)), "");
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.Level3Code.GDBnuuyObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDCarrotObjects1Objects = Hashtable.newFrom({"Carrot": gdjs.Level3Code.GDCarrotObjects1});
gdjs.Level3Code.eventsList30 = function(runtimeScene) {

{



}


{


gdjs.Level3Code.eventsList0(runtimeScene);
}


{


gdjs.Level3Code.eventsList16(runtimeScene);
}


{


gdjs.Level3Code.eventsList17(runtimeScene);
}


{


gdjs.Level3Code.eventsList18(runtimeScene);
}


{


gdjs.Level3Code.eventsList20(runtimeScene);
}


{


gdjs.Level3Code.eventsList22(runtimeScene);
}


{


gdjs.Level3Code.eventsList24(runtimeScene);
}


{


gdjs.Level3Code.eventsList28(runtimeScene);
}


{


gdjs.Level3Code.eventsList29(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.Level3Code.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carrot"), gdjs.Level3Code.GDCarrotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBnuuyObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDCarrotObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDCarrotObjects1 */
{for(var i = 0, len = gdjs.Level3Code.GDCarrotObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDCarrotObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-bonus-earned-in-video-game-2058.wav", false, 50, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level4", false);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(128);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(32);
}}

}


};

gdjs.Level3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level3Code.GDBnuuyObjects1.length = 0;
gdjs.Level3Code.GDBnuuyObjects2.length = 0;
gdjs.Level3Code.GDBnuuyObjects3.length = 0;
gdjs.Level3Code.GDBnuuyObjects4.length = 0;
gdjs.Level3Code.GDBnuuyObjects5.length = 0;
gdjs.Level3Code.GDBnuuyObjects6.length = 0;
gdjs.Level3Code.GDBnuuyObjects7.length = 0;
gdjs.Level3Code.GDBnuuyObjects8.length = 0;
gdjs.Level3Code.GDseaObjects1.length = 0;
gdjs.Level3Code.GDseaObjects2.length = 0;
gdjs.Level3Code.GDseaObjects3.length = 0;
gdjs.Level3Code.GDseaObjects4.length = 0;
gdjs.Level3Code.GDseaObjects5.length = 0;
gdjs.Level3Code.GDseaObjects6.length = 0;
gdjs.Level3Code.GDseaObjects7.length = 0;
gdjs.Level3Code.GDseaObjects8.length = 0;
gdjs.Level3Code.GDGrassObjects1.length = 0;
gdjs.Level3Code.GDGrassObjects2.length = 0;
gdjs.Level3Code.GDGrassObjects3.length = 0;
gdjs.Level3Code.GDGrassObjects4.length = 0;
gdjs.Level3Code.GDGrassObjects5.length = 0;
gdjs.Level3Code.GDGrassObjects6.length = 0;
gdjs.Level3Code.GDGrassObjects7.length = 0;
gdjs.Level3Code.GDGrassObjects8.length = 0;
gdjs.Level3Code.GDDirtObjects1.length = 0;
gdjs.Level3Code.GDDirtObjects2.length = 0;
gdjs.Level3Code.GDDirtObjects3.length = 0;
gdjs.Level3Code.GDDirtObjects4.length = 0;
gdjs.Level3Code.GDDirtObjects5.length = 0;
gdjs.Level3Code.GDDirtObjects6.length = 0;
gdjs.Level3Code.GDDirtObjects7.length = 0;
gdjs.Level3Code.GDDirtObjects8.length = 0;
gdjs.Level3Code.GDInvisWallObjects1.length = 0;
gdjs.Level3Code.GDInvisWallObjects2.length = 0;
gdjs.Level3Code.GDInvisWallObjects3.length = 0;
gdjs.Level3Code.GDInvisWallObjects4.length = 0;
gdjs.Level3Code.GDInvisWallObjects5.length = 0;
gdjs.Level3Code.GDInvisWallObjects6.length = 0;
gdjs.Level3Code.GDInvisWallObjects7.length = 0;
gdjs.Level3Code.GDInvisWallObjects8.length = 0;
gdjs.Level3Code.GDInvisWall2Objects1.length = 0;
gdjs.Level3Code.GDInvisWall2Objects2.length = 0;
gdjs.Level3Code.GDInvisWall2Objects3.length = 0;
gdjs.Level3Code.GDInvisWall2Objects4.length = 0;
gdjs.Level3Code.GDInvisWall2Objects5.length = 0;
gdjs.Level3Code.GDInvisWall2Objects6.length = 0;
gdjs.Level3Code.GDInvisWall2Objects7.length = 0;
gdjs.Level3Code.GDInvisWall2Objects8.length = 0;
gdjs.Level3Code.GDDashParticleObjects1.length = 0;
gdjs.Level3Code.GDDashParticleObjects2.length = 0;
gdjs.Level3Code.GDDashParticleObjects3.length = 0;
gdjs.Level3Code.GDDashParticleObjects4.length = 0;
gdjs.Level3Code.GDDashParticleObjects5.length = 0;
gdjs.Level3Code.GDDashParticleObjects6.length = 0;
gdjs.Level3Code.GDDashParticleObjects7.length = 0;
gdjs.Level3Code.GDDashParticleObjects8.length = 0;
gdjs.Level3Code.GDLandParticlesObjects1.length = 0;
gdjs.Level3Code.GDLandParticlesObjects2.length = 0;
gdjs.Level3Code.GDLandParticlesObjects3.length = 0;
gdjs.Level3Code.GDLandParticlesObjects4.length = 0;
gdjs.Level3Code.GDLandParticlesObjects5.length = 0;
gdjs.Level3Code.GDLandParticlesObjects6.length = 0;
gdjs.Level3Code.GDLandParticlesObjects7.length = 0;
gdjs.Level3Code.GDLandParticlesObjects8.length = 0;
gdjs.Level3Code.GDLandParticles3Objects1.length = 0;
gdjs.Level3Code.GDLandParticles3Objects2.length = 0;
gdjs.Level3Code.GDLandParticles3Objects3.length = 0;
gdjs.Level3Code.GDLandParticles3Objects4.length = 0;
gdjs.Level3Code.GDLandParticles3Objects5.length = 0;
gdjs.Level3Code.GDLandParticles3Objects6.length = 0;
gdjs.Level3Code.GDLandParticles3Objects7.length = 0;
gdjs.Level3Code.GDLandParticles3Objects8.length = 0;
gdjs.Level3Code.GDLandParticles2Objects1.length = 0;
gdjs.Level3Code.GDLandParticles2Objects2.length = 0;
gdjs.Level3Code.GDLandParticles2Objects3.length = 0;
gdjs.Level3Code.GDLandParticles2Objects4.length = 0;
gdjs.Level3Code.GDLandParticles2Objects5.length = 0;
gdjs.Level3Code.GDLandParticles2Objects6.length = 0;
gdjs.Level3Code.GDLandParticles2Objects7.length = 0;
gdjs.Level3Code.GDLandParticles2Objects8.length = 0;
gdjs.Level3Code.GDCarrotObjects1.length = 0;
gdjs.Level3Code.GDCarrotObjects2.length = 0;
gdjs.Level3Code.GDCarrotObjects3.length = 0;
gdjs.Level3Code.GDCarrotObjects4.length = 0;
gdjs.Level3Code.GDCarrotObjects5.length = 0;
gdjs.Level3Code.GDCarrotObjects6.length = 0;
gdjs.Level3Code.GDCarrotObjects7.length = 0;
gdjs.Level3Code.GDCarrotObjects8.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects1.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects2.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects3.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects4.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects5.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects6.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects7.length = 0;
gdjs.Level3Code.GDSadBNUUYObjects8.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects1.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects2.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects3.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects4.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects5.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects6.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects7.length = 0;
gdjs.Level3Code.GDDebuggerTextObjects8.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects1.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects2.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects3.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects4.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects5.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects6.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects7.length = 0;
gdjs.Level3Code.GDBnuuyDashAfterLeftObjects8.length = 0;
gdjs.Level3Code.GDLandParticles4Objects1.length = 0;
gdjs.Level3Code.GDLandParticles4Objects2.length = 0;
gdjs.Level3Code.GDLandParticles4Objects3.length = 0;
gdjs.Level3Code.GDLandParticles4Objects4.length = 0;
gdjs.Level3Code.GDLandParticles4Objects5.length = 0;
gdjs.Level3Code.GDLandParticles4Objects6.length = 0;
gdjs.Level3Code.GDLandParticles4Objects7.length = 0;
gdjs.Level3Code.GDLandParticles4Objects8.length = 0;
gdjs.Level3Code.GDSawbladeObjects1.length = 0;
gdjs.Level3Code.GDSawbladeObjects2.length = 0;
gdjs.Level3Code.GDSawbladeObjects3.length = 0;
gdjs.Level3Code.GDSawbladeObjects4.length = 0;
gdjs.Level3Code.GDSawbladeObjects5.length = 0;
gdjs.Level3Code.GDSawbladeObjects6.length = 0;
gdjs.Level3Code.GDSawbladeObjects7.length = 0;
gdjs.Level3Code.GDSawbladeObjects8.length = 0;
gdjs.Level3Code.GDDeathObjects1.length = 0;
gdjs.Level3Code.GDDeathObjects2.length = 0;
gdjs.Level3Code.GDDeathObjects3.length = 0;
gdjs.Level3Code.GDDeathObjects4.length = 0;
gdjs.Level3Code.GDDeathObjects5.length = 0;
gdjs.Level3Code.GDDeathObjects6.length = 0;
gdjs.Level3Code.GDDeathObjects7.length = 0;
gdjs.Level3Code.GDDeathObjects8.length = 0;
gdjs.Level3Code.GDDeathLeftObjects1.length = 0;
gdjs.Level3Code.GDDeathLeftObjects2.length = 0;
gdjs.Level3Code.GDDeathLeftObjects3.length = 0;
gdjs.Level3Code.GDDeathLeftObjects4.length = 0;
gdjs.Level3Code.GDDeathLeftObjects5.length = 0;
gdjs.Level3Code.GDDeathLeftObjects6.length = 0;
gdjs.Level3Code.GDDeathLeftObjects7.length = 0;
gdjs.Level3Code.GDDeathLeftObjects8.length = 0;
gdjs.Level3Code.GDFoxObjects1.length = 0;
gdjs.Level3Code.GDFoxObjects2.length = 0;
gdjs.Level3Code.GDFoxObjects3.length = 0;
gdjs.Level3Code.GDFoxObjects4.length = 0;
gdjs.Level3Code.GDFoxObjects5.length = 0;
gdjs.Level3Code.GDFoxObjects6.length = 0;
gdjs.Level3Code.GDFoxObjects7.length = 0;
gdjs.Level3Code.GDFoxObjects8.length = 0;
gdjs.Level3Code.GDOrbObjects1.length = 0;
gdjs.Level3Code.GDOrbObjects2.length = 0;
gdjs.Level3Code.GDOrbObjects3.length = 0;
gdjs.Level3Code.GDOrbObjects4.length = 0;
gdjs.Level3Code.GDOrbObjects5.length = 0;
gdjs.Level3Code.GDOrbObjects6.length = 0;
gdjs.Level3Code.GDOrbObjects7.length = 0;
gdjs.Level3Code.GDOrbObjects8.length = 0;
gdjs.Level3Code.GDArrowObjects1.length = 0;
gdjs.Level3Code.GDArrowObjects2.length = 0;
gdjs.Level3Code.GDArrowObjects3.length = 0;
gdjs.Level3Code.GDArrowObjects4.length = 0;
gdjs.Level3Code.GDArrowObjects5.length = 0;
gdjs.Level3Code.GDArrowObjects6.length = 0;
gdjs.Level3Code.GDArrowObjects7.length = 0;
gdjs.Level3Code.GDArrowObjects8.length = 0;
gdjs.Level3Code.GDDirtHalfObjects1.length = 0;
gdjs.Level3Code.GDDirtHalfObjects2.length = 0;
gdjs.Level3Code.GDDirtHalfObjects3.length = 0;
gdjs.Level3Code.GDDirtHalfObjects4.length = 0;
gdjs.Level3Code.GDDirtHalfObjects5.length = 0;
gdjs.Level3Code.GDDirtHalfObjects6.length = 0;
gdjs.Level3Code.GDDirtHalfObjects7.length = 0;
gdjs.Level3Code.GDDirtHalfObjects8.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects1.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects2.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects3.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects4.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects5.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects6.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects7.length = 0;
gdjs.Level3Code.GDSawbladeUpDownObjects8.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects1.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects2.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects3.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects4.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects5.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects6.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects7.length = 0;
gdjs.Level3Code.GDSawbladeLeftRightObjects8.length = 0;
gdjs.Level3Code.GDJumpthruObjects1.length = 0;
gdjs.Level3Code.GDJumpthruObjects2.length = 0;
gdjs.Level3Code.GDJumpthruObjects3.length = 0;
gdjs.Level3Code.GDJumpthruObjects4.length = 0;
gdjs.Level3Code.GDJumpthruObjects5.length = 0;
gdjs.Level3Code.GDJumpthruObjects6.length = 0;
gdjs.Level3Code.GDJumpthruObjects7.length = 0;
gdjs.Level3Code.GDJumpthruObjects8.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects1.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects2.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects3.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects4.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects5.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects6.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects7.length = 0;
gdjs.Level3Code.GDDoubleOrbObjects8.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects1.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects2.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects3.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects4.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects5.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects6.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects7.length = 0;
gdjs.Level3Code.GDOrbSpawnerObjects8.length = 0;

gdjs.Level3Code.eventsList30(runtimeScene);

return;

}

gdjs['Level3Code'] = gdjs.Level3Code;
