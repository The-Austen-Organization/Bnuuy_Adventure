gdjs.EndingCode = {};
gdjs.EndingCode.GDNewTextObjects1= [];
gdjs.EndingCode.GDNewTextObjects2= [];
gdjs.EndingCode.GDBnuuyObjects1= [];
gdjs.EndingCode.GDBnuuyObjects2= [];
gdjs.EndingCode.GDseaObjects1= [];
gdjs.EndingCode.GDseaObjects2= [];
gdjs.EndingCode.GDGrassObjects1= [];
gdjs.EndingCode.GDGrassObjects2= [];
gdjs.EndingCode.GDDirtObjects1= [];
gdjs.EndingCode.GDDirtObjects2= [];
gdjs.EndingCode.GDInvisWallObjects1= [];
gdjs.EndingCode.GDInvisWallObjects2= [];
gdjs.EndingCode.GDInvisWall2Objects1= [];
gdjs.EndingCode.GDInvisWall2Objects2= [];
gdjs.EndingCode.GDDashParticleObjects1= [];
gdjs.EndingCode.GDDashParticleObjects2= [];
gdjs.EndingCode.GDLandParticlesObjects1= [];
gdjs.EndingCode.GDLandParticlesObjects2= [];
gdjs.EndingCode.GDLandParticles3Objects1= [];
gdjs.EndingCode.GDLandParticles3Objects2= [];
gdjs.EndingCode.GDLandParticles2Objects1= [];
gdjs.EndingCode.GDLandParticles2Objects2= [];
gdjs.EndingCode.GDCarrotObjects1= [];
gdjs.EndingCode.GDCarrotObjects2= [];
gdjs.EndingCode.GDSadBNUUYObjects1= [];
gdjs.EndingCode.GDSadBNUUYObjects2= [];
gdjs.EndingCode.GDDebuggerTextObjects1= [];
gdjs.EndingCode.GDDebuggerTextObjects2= [];
gdjs.EndingCode.GDBnuuyDashAfterLeftObjects1= [];
gdjs.EndingCode.GDBnuuyDashAfterLeftObjects2= [];
gdjs.EndingCode.GDLandParticles4Objects1= [];
gdjs.EndingCode.GDLandParticles4Objects2= [];
gdjs.EndingCode.GDSawbladeObjects1= [];
gdjs.EndingCode.GDSawbladeObjects2= [];
gdjs.EndingCode.GDDeathObjects1= [];
gdjs.EndingCode.GDDeathObjects2= [];
gdjs.EndingCode.GDDeathLeftObjects1= [];
gdjs.EndingCode.GDDeathLeftObjects2= [];
gdjs.EndingCode.GDFoxObjects1= [];
gdjs.EndingCode.GDFoxObjects2= [];
gdjs.EndingCode.GDOrbObjects1= [];
gdjs.EndingCode.GDOrbObjects2= [];
gdjs.EndingCode.GDArrowObjects1= [];
gdjs.EndingCode.GDArrowObjects2= [];
gdjs.EndingCode.GDDirtHalfObjects1= [];
gdjs.EndingCode.GDDirtHalfObjects2= [];
gdjs.EndingCode.GDSawbladeUpDownObjects1= [];
gdjs.EndingCode.GDSawbladeUpDownObjects2= [];
gdjs.EndingCode.GDSawbladeLeftRightObjects1= [];
gdjs.EndingCode.GDSawbladeLeftRightObjects2= [];
gdjs.EndingCode.GDJumpthruObjects1= [];
gdjs.EndingCode.GDJumpthruObjects2= [];
gdjs.EndingCode.GDDoubleOrbObjects1= [];
gdjs.EndingCode.GDDoubleOrbObjects2= [];
gdjs.EndingCode.GDOrbSpawnerObjects1= [];
gdjs.EndingCode.GDOrbSpawnerObjects2= [];


gdjs.EndingCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.EndingCode.GDBnuuyObjects1);
{for(var i = 0, len = gdjs.EndingCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.EndingCode.GDBnuuyObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}}

}


};

gdjs.EndingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EndingCode.GDNewTextObjects1.length = 0;
gdjs.EndingCode.GDNewTextObjects2.length = 0;
gdjs.EndingCode.GDBnuuyObjects1.length = 0;
gdjs.EndingCode.GDBnuuyObjects2.length = 0;
gdjs.EndingCode.GDseaObjects1.length = 0;
gdjs.EndingCode.GDseaObjects2.length = 0;
gdjs.EndingCode.GDGrassObjects1.length = 0;
gdjs.EndingCode.GDGrassObjects2.length = 0;
gdjs.EndingCode.GDDirtObjects1.length = 0;
gdjs.EndingCode.GDDirtObjects2.length = 0;
gdjs.EndingCode.GDInvisWallObjects1.length = 0;
gdjs.EndingCode.GDInvisWallObjects2.length = 0;
gdjs.EndingCode.GDInvisWall2Objects1.length = 0;
gdjs.EndingCode.GDInvisWall2Objects2.length = 0;
gdjs.EndingCode.GDDashParticleObjects1.length = 0;
gdjs.EndingCode.GDDashParticleObjects2.length = 0;
gdjs.EndingCode.GDLandParticlesObjects1.length = 0;
gdjs.EndingCode.GDLandParticlesObjects2.length = 0;
gdjs.EndingCode.GDLandParticles3Objects1.length = 0;
gdjs.EndingCode.GDLandParticles3Objects2.length = 0;
gdjs.EndingCode.GDLandParticles2Objects1.length = 0;
gdjs.EndingCode.GDLandParticles2Objects2.length = 0;
gdjs.EndingCode.GDCarrotObjects1.length = 0;
gdjs.EndingCode.GDCarrotObjects2.length = 0;
gdjs.EndingCode.GDSadBNUUYObjects1.length = 0;
gdjs.EndingCode.GDSadBNUUYObjects2.length = 0;
gdjs.EndingCode.GDDebuggerTextObjects1.length = 0;
gdjs.EndingCode.GDDebuggerTextObjects2.length = 0;
gdjs.EndingCode.GDBnuuyDashAfterLeftObjects1.length = 0;
gdjs.EndingCode.GDBnuuyDashAfterLeftObjects2.length = 0;
gdjs.EndingCode.GDLandParticles4Objects1.length = 0;
gdjs.EndingCode.GDLandParticles4Objects2.length = 0;
gdjs.EndingCode.GDSawbladeObjects1.length = 0;
gdjs.EndingCode.GDSawbladeObjects2.length = 0;
gdjs.EndingCode.GDDeathObjects1.length = 0;
gdjs.EndingCode.GDDeathObjects2.length = 0;
gdjs.EndingCode.GDDeathLeftObjects1.length = 0;
gdjs.EndingCode.GDDeathLeftObjects2.length = 0;
gdjs.EndingCode.GDFoxObjects1.length = 0;
gdjs.EndingCode.GDFoxObjects2.length = 0;
gdjs.EndingCode.GDOrbObjects1.length = 0;
gdjs.EndingCode.GDOrbObjects2.length = 0;
gdjs.EndingCode.GDArrowObjects1.length = 0;
gdjs.EndingCode.GDArrowObjects2.length = 0;
gdjs.EndingCode.GDDirtHalfObjects1.length = 0;
gdjs.EndingCode.GDDirtHalfObjects2.length = 0;
gdjs.EndingCode.GDSawbladeUpDownObjects1.length = 0;
gdjs.EndingCode.GDSawbladeUpDownObjects2.length = 0;
gdjs.EndingCode.GDSawbladeLeftRightObjects1.length = 0;
gdjs.EndingCode.GDSawbladeLeftRightObjects2.length = 0;
gdjs.EndingCode.GDJumpthruObjects1.length = 0;
gdjs.EndingCode.GDJumpthruObjects2.length = 0;
gdjs.EndingCode.GDDoubleOrbObjects1.length = 0;
gdjs.EndingCode.GDDoubleOrbObjects2.length = 0;
gdjs.EndingCode.GDOrbSpawnerObjects1.length = 0;
gdjs.EndingCode.GDOrbSpawnerObjects2.length = 0;

gdjs.EndingCode.eventsList0(runtimeScene);

return;

}

gdjs['EndingCode'] = gdjs.EndingCode;
