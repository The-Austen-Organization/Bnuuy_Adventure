gdjs.BonusLevelCode = {};
gdjs.BonusLevelCode.GDThanksObjects1= [];
gdjs.BonusLevelCode.GDThanksObjects2= [];
gdjs.BonusLevelCode.GDThanksObjects3= [];
gdjs.BonusLevelCode.GDThanksObjects4= [];
gdjs.BonusLevelCode.GDThanksObjects5= [];
gdjs.BonusLevelCode.GDThanksObjects6= [];
gdjs.BonusLevelCode.GDThanksObjects7= [];
gdjs.BonusLevelCode.GDThanksObjects8= [];
gdjs.BonusLevelCode.GDBnuuyObjects1= [];
gdjs.BonusLevelCode.GDBnuuyObjects2= [];
gdjs.BonusLevelCode.GDBnuuyObjects3= [];
gdjs.BonusLevelCode.GDBnuuyObjects4= [];
gdjs.BonusLevelCode.GDBnuuyObjects5= [];
gdjs.BonusLevelCode.GDBnuuyObjects6= [];
gdjs.BonusLevelCode.GDBnuuyObjects7= [];
gdjs.BonusLevelCode.GDBnuuyObjects8= [];
gdjs.BonusLevelCode.GDseaObjects1= [];
gdjs.BonusLevelCode.GDseaObjects2= [];
gdjs.BonusLevelCode.GDseaObjects3= [];
gdjs.BonusLevelCode.GDseaObjects4= [];
gdjs.BonusLevelCode.GDseaObjects5= [];
gdjs.BonusLevelCode.GDseaObjects6= [];
gdjs.BonusLevelCode.GDseaObjects7= [];
gdjs.BonusLevelCode.GDseaObjects8= [];
gdjs.BonusLevelCode.GDGrassObjects1= [];
gdjs.BonusLevelCode.GDGrassObjects2= [];
gdjs.BonusLevelCode.GDGrassObjects3= [];
gdjs.BonusLevelCode.GDGrassObjects4= [];
gdjs.BonusLevelCode.GDGrassObjects5= [];
gdjs.BonusLevelCode.GDGrassObjects6= [];
gdjs.BonusLevelCode.GDGrassObjects7= [];
gdjs.BonusLevelCode.GDGrassObjects8= [];
gdjs.BonusLevelCode.GDDirtObjects1= [];
gdjs.BonusLevelCode.GDDirtObjects2= [];
gdjs.BonusLevelCode.GDDirtObjects3= [];
gdjs.BonusLevelCode.GDDirtObjects4= [];
gdjs.BonusLevelCode.GDDirtObjects5= [];
gdjs.BonusLevelCode.GDDirtObjects6= [];
gdjs.BonusLevelCode.GDDirtObjects7= [];
gdjs.BonusLevelCode.GDDirtObjects8= [];
gdjs.BonusLevelCode.GDInvisWallObjects1= [];
gdjs.BonusLevelCode.GDInvisWallObjects2= [];
gdjs.BonusLevelCode.GDInvisWallObjects3= [];
gdjs.BonusLevelCode.GDInvisWallObjects4= [];
gdjs.BonusLevelCode.GDInvisWallObjects5= [];
gdjs.BonusLevelCode.GDInvisWallObjects6= [];
gdjs.BonusLevelCode.GDInvisWallObjects7= [];
gdjs.BonusLevelCode.GDInvisWallObjects8= [];
gdjs.BonusLevelCode.GDInvisWall2Objects1= [];
gdjs.BonusLevelCode.GDInvisWall2Objects2= [];
gdjs.BonusLevelCode.GDInvisWall2Objects3= [];
gdjs.BonusLevelCode.GDInvisWall2Objects4= [];
gdjs.BonusLevelCode.GDInvisWall2Objects5= [];
gdjs.BonusLevelCode.GDInvisWall2Objects6= [];
gdjs.BonusLevelCode.GDInvisWall2Objects7= [];
gdjs.BonusLevelCode.GDInvisWall2Objects8= [];
gdjs.BonusLevelCode.GDDashParticleObjects1= [];
gdjs.BonusLevelCode.GDDashParticleObjects2= [];
gdjs.BonusLevelCode.GDDashParticleObjects3= [];
gdjs.BonusLevelCode.GDDashParticleObjects4= [];
gdjs.BonusLevelCode.GDDashParticleObjects5= [];
gdjs.BonusLevelCode.GDDashParticleObjects6= [];
gdjs.BonusLevelCode.GDDashParticleObjects7= [];
gdjs.BonusLevelCode.GDDashParticleObjects8= [];
gdjs.BonusLevelCode.GDLandParticlesObjects1= [];
gdjs.BonusLevelCode.GDLandParticlesObjects2= [];
gdjs.BonusLevelCode.GDLandParticlesObjects3= [];
gdjs.BonusLevelCode.GDLandParticlesObjects4= [];
gdjs.BonusLevelCode.GDLandParticlesObjects5= [];
gdjs.BonusLevelCode.GDLandParticlesObjects6= [];
gdjs.BonusLevelCode.GDLandParticlesObjects7= [];
gdjs.BonusLevelCode.GDLandParticlesObjects8= [];
gdjs.BonusLevelCode.GDLandParticles3Objects1= [];
gdjs.BonusLevelCode.GDLandParticles3Objects2= [];
gdjs.BonusLevelCode.GDLandParticles3Objects3= [];
gdjs.BonusLevelCode.GDLandParticles3Objects4= [];
gdjs.BonusLevelCode.GDLandParticles3Objects5= [];
gdjs.BonusLevelCode.GDLandParticles3Objects6= [];
gdjs.BonusLevelCode.GDLandParticles3Objects7= [];
gdjs.BonusLevelCode.GDLandParticles3Objects8= [];
gdjs.BonusLevelCode.GDLandParticles2Objects1= [];
gdjs.BonusLevelCode.GDLandParticles2Objects2= [];
gdjs.BonusLevelCode.GDLandParticles2Objects3= [];
gdjs.BonusLevelCode.GDLandParticles2Objects4= [];
gdjs.BonusLevelCode.GDLandParticles2Objects5= [];
gdjs.BonusLevelCode.GDLandParticles2Objects6= [];
gdjs.BonusLevelCode.GDLandParticles2Objects7= [];
gdjs.BonusLevelCode.GDLandParticles2Objects8= [];
gdjs.BonusLevelCode.GDCarrotObjects1= [];
gdjs.BonusLevelCode.GDCarrotObjects2= [];
gdjs.BonusLevelCode.GDCarrotObjects3= [];
gdjs.BonusLevelCode.GDCarrotObjects4= [];
gdjs.BonusLevelCode.GDCarrotObjects5= [];
gdjs.BonusLevelCode.GDCarrotObjects6= [];
gdjs.BonusLevelCode.GDCarrotObjects7= [];
gdjs.BonusLevelCode.GDCarrotObjects8= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects1= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects2= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects3= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects4= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects5= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects6= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects7= [];
gdjs.BonusLevelCode.GDSadBNUUYObjects8= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects1= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects2= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects3= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects4= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects5= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects6= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects7= [];
gdjs.BonusLevelCode.GDDebuggerTextObjects8= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects1= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects2= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects3= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects4= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects5= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects6= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7= [];
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects8= [];
gdjs.BonusLevelCode.GDLandParticles4Objects1= [];
gdjs.BonusLevelCode.GDLandParticles4Objects2= [];
gdjs.BonusLevelCode.GDLandParticles4Objects3= [];
gdjs.BonusLevelCode.GDLandParticles4Objects4= [];
gdjs.BonusLevelCode.GDLandParticles4Objects5= [];
gdjs.BonusLevelCode.GDLandParticles4Objects6= [];
gdjs.BonusLevelCode.GDLandParticles4Objects7= [];
gdjs.BonusLevelCode.GDLandParticles4Objects8= [];
gdjs.BonusLevelCode.GDSawbladeObjects1= [];
gdjs.BonusLevelCode.GDSawbladeObjects2= [];
gdjs.BonusLevelCode.GDSawbladeObjects3= [];
gdjs.BonusLevelCode.GDSawbladeObjects4= [];
gdjs.BonusLevelCode.GDSawbladeObjects5= [];
gdjs.BonusLevelCode.GDSawbladeObjects6= [];
gdjs.BonusLevelCode.GDSawbladeObjects7= [];
gdjs.BonusLevelCode.GDSawbladeObjects8= [];
gdjs.BonusLevelCode.GDDeathObjects1= [];
gdjs.BonusLevelCode.GDDeathObjects2= [];
gdjs.BonusLevelCode.GDDeathObjects3= [];
gdjs.BonusLevelCode.GDDeathObjects4= [];
gdjs.BonusLevelCode.GDDeathObjects5= [];
gdjs.BonusLevelCode.GDDeathObjects6= [];
gdjs.BonusLevelCode.GDDeathObjects7= [];
gdjs.BonusLevelCode.GDDeathObjects8= [];
gdjs.BonusLevelCode.GDDeathLeftObjects1= [];
gdjs.BonusLevelCode.GDDeathLeftObjects2= [];
gdjs.BonusLevelCode.GDDeathLeftObjects3= [];
gdjs.BonusLevelCode.GDDeathLeftObjects4= [];
gdjs.BonusLevelCode.GDDeathLeftObjects5= [];
gdjs.BonusLevelCode.GDDeathLeftObjects6= [];
gdjs.BonusLevelCode.GDDeathLeftObjects7= [];
gdjs.BonusLevelCode.GDDeathLeftObjects8= [];
gdjs.BonusLevelCode.GDFoxObjects1= [];
gdjs.BonusLevelCode.GDFoxObjects2= [];
gdjs.BonusLevelCode.GDFoxObjects3= [];
gdjs.BonusLevelCode.GDFoxObjects4= [];
gdjs.BonusLevelCode.GDFoxObjects5= [];
gdjs.BonusLevelCode.GDFoxObjects6= [];
gdjs.BonusLevelCode.GDFoxObjects7= [];
gdjs.BonusLevelCode.GDFoxObjects8= [];
gdjs.BonusLevelCode.GDOrbObjects1= [];
gdjs.BonusLevelCode.GDOrbObjects2= [];
gdjs.BonusLevelCode.GDOrbObjects3= [];
gdjs.BonusLevelCode.GDOrbObjects4= [];
gdjs.BonusLevelCode.GDOrbObjects5= [];
gdjs.BonusLevelCode.GDOrbObjects6= [];
gdjs.BonusLevelCode.GDOrbObjects7= [];
gdjs.BonusLevelCode.GDOrbObjects8= [];
gdjs.BonusLevelCode.GDArrowObjects1= [];
gdjs.BonusLevelCode.GDArrowObjects2= [];
gdjs.BonusLevelCode.GDArrowObjects3= [];
gdjs.BonusLevelCode.GDArrowObjects4= [];
gdjs.BonusLevelCode.GDArrowObjects5= [];
gdjs.BonusLevelCode.GDArrowObjects6= [];
gdjs.BonusLevelCode.GDArrowObjects7= [];
gdjs.BonusLevelCode.GDArrowObjects8= [];
gdjs.BonusLevelCode.GDDirtHalfObjects1= [];
gdjs.BonusLevelCode.GDDirtHalfObjects2= [];
gdjs.BonusLevelCode.GDDirtHalfObjects3= [];
gdjs.BonusLevelCode.GDDirtHalfObjects4= [];
gdjs.BonusLevelCode.GDDirtHalfObjects5= [];
gdjs.BonusLevelCode.GDDirtHalfObjects6= [];
gdjs.BonusLevelCode.GDDirtHalfObjects7= [];
gdjs.BonusLevelCode.GDDirtHalfObjects8= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects1= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects2= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects3= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects4= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects5= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects6= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects7= [];
gdjs.BonusLevelCode.GDSawbladeUpDownObjects8= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects2= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects3= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects4= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects5= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects6= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects7= [];
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects8= [];
gdjs.BonusLevelCode.GDJumpthruObjects1= [];
gdjs.BonusLevelCode.GDJumpthruObjects2= [];
gdjs.BonusLevelCode.GDJumpthruObjects3= [];
gdjs.BonusLevelCode.GDJumpthruObjects4= [];
gdjs.BonusLevelCode.GDJumpthruObjects5= [];
gdjs.BonusLevelCode.GDJumpthruObjects6= [];
gdjs.BonusLevelCode.GDJumpthruObjects7= [];
gdjs.BonusLevelCode.GDJumpthruObjects8= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects1= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects2= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects3= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects4= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects5= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects6= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects7= [];
gdjs.BonusLevelCode.GDDoubleOrbObjects8= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects1= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects2= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects3= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects4= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects5= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects6= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects7= [];
gdjs.BonusLevelCode.GDOrbSpawnerObjects8= [];


gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.BonusLevelCode.GDBnuuyObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDCarrotObjects1Objects = Hashtable.newFrom({"Carrot": gdjs.BonusLevelCode.GDCarrotObjects1});
gdjs.BonusLevelCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.BonusLevelCode.GDArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carrot"), gdjs.BonusLevelCode.GDCarrotObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dirt"), gdjs.BonusLevelCode.GDDirtObjects1);
gdjs.copyArray(runtimeScene.getObjects("DoubleOrb"), gdjs.BonusLevelCode.GDDoubleOrbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Grass"), gdjs.BonusLevelCode.GDGrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("Orb"), gdjs.BonusLevelCode.GDOrbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sawblade"), gdjs.BonusLevelCode.GDSawbladeObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeLeftRight"), gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeUpDown"), gdjs.BonusLevelCode.GDSawbladeUpDownObjects1);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDCarrotObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDCarrotObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{}{}{for(var i = 0, len = gdjs.BonusLevelCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDArrowObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 4, 4, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDOrbObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDOrbObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 6, 6, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDOrbObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDOrbObjects1[i].getBehavior("Tween").addObjectOpacityTween("Opacity", 140, "easeInOutQuad", 200, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 8, 8, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeUpDownObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeUpDownObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 8, 8, "elastic", 50, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 8, 8, "elastic", 50, false, true);
}
}{runtimeScene.getGame().getVariables().get("Bruh").setString("Right");
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(1);
}{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects1[i].returnVariable(gdjs.BonusLevelCode.GDFoxObjects1[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber((( gdjs.BonusLevelCode.GDDoubleOrbObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDDoubleOrbObjects1[0].getPointY("")));
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber((( gdjs.BonusLevelCode.GDDoubleOrbObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDDoubleOrbObjects1[0].getPointX("")));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeObjects1[i].setZOrder(220);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeUpDownObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeUpDownObjects1[i].setZOrder(220);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1[i].setZOrder(220);
}
}}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects3Objects = Hashtable.newFrom({"SadBNUUY": gdjs.BonusLevelCode.GDSadBNUUYObjects3});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects4Objects = Hashtable.newFrom({"SadBNUUY": gdjs.BonusLevelCode.GDSadBNUUYObjects4});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects5Objects = Hashtable.newFrom({"SadBNUUY": gdjs.BonusLevelCode.GDSadBNUUYObjects5});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects6Objects = Hashtable.newFrom({"SadBNUUY": gdjs.BonusLevelCode.GDSadBNUUYObjects6});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects7Objects = Hashtable.newFrom({"SadBNUUY": gdjs.BonusLevelCode.GDSadBNUUYObjects7});
gdjs.BonusLevelCode.asyncCallback17048756 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.BonusLevelCode.GDSadBNUUYObjects8);

{for(var i = 0, len = gdjs.BonusLevelCode.GDSadBNUUYObjects8.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSadBNUUYObjects8[i].getBehavior("Tween").addObjectScaleTween("ByeBnuuy", 0.6, 0.6, "easeInOutQuad", 400, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDSadBNUUYObjects8.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSadBNUUYObjects8[i].getBehavior("Tween").addObjectOpacityTween("Dissapear", 0, "easeOutQuart", 400, true);
}
}}
gdjs.BonusLevelCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDSadBNUUYObjects7) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.05), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17048756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17047772 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects7);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.BonusLevelCode.GDSadBNUUYObjects7);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects7Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects7.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects7[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects7.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects7[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects6) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDSadBNUUYObjects6) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17047772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17048132 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects6);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.BonusLevelCode.GDSadBNUUYObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects6Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects6[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects6[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects5) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDSadBNUUYObjects5) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17048132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17047140 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.BonusLevelCode.GDSadBNUUYObjects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects5Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects5[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects5[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects4) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDSadBNUUYObjects4) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17047140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17047044 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("SadBNUUY"), gdjs.BonusLevelCode.GDSadBNUUYObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects4Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects4[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects4[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects3) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDSadBNUUYObjects3) asyncObjectsList.addObject("SadBNUUY", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17047044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects2Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects3Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects3});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects4Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects4});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects5Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects5});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects6Objects = Hashtable.newFrom({"BnuuyDashAfterLeft": gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects6});
gdjs.BonusLevelCode.asyncCallback17051852 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7);

{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7[i].getBehavior("Tween").addObjectScaleTween("ByeBnuuyLeft", 0.6, 0.6, "easeInOutQuad", 400, false, true);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7[i].getBehavior("Tween").addObjectOpacityTween("DissapearLeft", 0, "easeOutQuart", 400, true);
}
}}
gdjs.BonusLevelCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects6) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.05), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17051852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17051924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects6);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects6Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects6[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects6.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects6[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects5) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects5) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17051924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17051540 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects5Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects5[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects5.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects5[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects4) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects4) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17051540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17049924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects4Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects4[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects4.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects4[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects3) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects3) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17049924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17049188 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("BnuuyDashAfterLeft"), gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects3);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects3Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BonusLevelCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.BonusLevelCode.GDBnuuyObjects2) asyncObjectsList.addObject("Bnuuy", obj);
for (const obj of gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects2) asyncObjectsList.addObject("BnuuyDashAfterLeft", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17049188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.BonusLevelCode.GDBnuuyObjects2, gdjs.BonusLevelCode.GDBnuuyObjects3);

gdjs.BonusLevelCode.GDSadBNUUYObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSadBNUUYObjects3Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects2 */
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyDashAfterLeftObjects2Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.BonusLevelCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.BonusLevelCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BonusLevelCode.GDBnuuyObjects2, gdjs.BonusLevelCode.GDBnuuyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects3.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDBnuuyObjects3[i].getVariableNumber(gdjs.BonusLevelCode.GDBnuuyObjects3[i].getVariables().getFromIndex(0)) == -(10) ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects3[k] = gdjs.BonusLevelCode.GDBnuuyObjects3[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects3 */
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].returnVariable(gdjs.BonusLevelCode.GDBnuuyObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


{

/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDBnuuyObjects2[i].getVariableNumber(gdjs.BonusLevelCode.GDBnuuyObjects2[i].getVariables().getFromIndex(0)) == 10 ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects2[k] = gdjs.BonusLevelCode.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects2 */
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].returnVariable(gdjs.BonusLevelCode.GDBnuuyObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.BonusLevelCode.asyncCallback17061628 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects3);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].returnVariable(gdjs.BonusLevelCode.GDBnuuyObjects3[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}}
gdjs.BonusLevelCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17061628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17063076 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects3);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].returnVariable(gdjs.BonusLevelCode.GDBnuuyObjects3[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}}
gdjs.BonusLevelCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17063076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17064220 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].returnVariable(gdjs.BonusLevelCode.GDBnuuyObjects2[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}}
gdjs.BonusLevelCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17064220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects2[k] = gdjs.BonusLevelCode.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17045420);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "a54eee0a33e2249eb99f672c676f5c643369128d38b234af317fd5677a26ec70_Jump_Start_01.wav", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("HorizontalDash").IsDashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects2[k] = gdjs.BonusLevelCode.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17046740);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "24911cec3e29b654a6e4bdd454756546c5492abdfc4f7f0ecc4cffebee5171d6_Hard_Run_06.wav", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}
{ //Subevents
gdjs.BonusLevelCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects2.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects2[k] = gdjs.BonusLevelCode.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17057828);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects2 */
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].returnVariable(gdjs.BonusLevelCode.GDBnuuyObjects2[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects2.length;i<l;++i) {
    if ( !(gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects2[k] = gdjs.BonusLevelCode.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17059308);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 2;
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.BonusLevelCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects2.length;i<l;++i) {
    if ( !(gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects2[k] = gdjs.BonusLevelCode.GDBnuuyObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DebuggerText"), gdjs.BonusLevelCode.GDDebuggerTextObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDDebuggerTextObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDebuggerTextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDBnuuyObjects1.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDBnuuyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDBnuuyObjects1[k] = gdjs.BonusLevelCode.GDBnuuyObjects1[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDBnuuyObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DebuggerText"), gdjs.BonusLevelCode.GDDebuggerTextObjects1);
{for(var i = 0, len = gdjs.BonusLevelCode.GDDebuggerTextObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDebuggerTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")));
}
}}

}


};gdjs.BonusLevelCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{runtimeScene.getGame().getVariables().get("Bruh").setString("Right");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{runtimeScene.getGame().getVariables().get("Bruh").setString("Left");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "j");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "B", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Gamepads__C_Button_pressed.func(runtimeScene, 1, "X", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);
{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.BonusLevelCode.GDBnuuyObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSawbladeObjects1Objects = Hashtable.newFrom({"Sawblade": gdjs.BonusLevelCode.GDSawbladeObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects2Objects = Hashtable.newFrom({"Death": gdjs.BonusLevelCode.GDDeathObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects1Objects = Hashtable.newFrom({"DeathLeft": gdjs.BonusLevelCode.GDDeathLeftObjects1});
gdjs.BonusLevelCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.BonusLevelCode.GDBnuuyObjects1, gdjs.BonusLevelCode.GDBnuuyObjects2);

gdjs.BonusLevelCode.GDDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects2Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects1 */
gdjs.BonusLevelCode.GDDeathLeftObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects1Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.BonusLevelCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Sawblade"), gdjs.BonusLevelCode.GDSawbladeObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeObjects2[i].rotate(360, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sawblade"), gdjs.BonusLevelCode.GDSawbladeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects, gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSawbladeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.BonusLevelCode.GDBnuuyObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSawbladeUpDownObjects1Objects = Hashtable.newFrom({"SawbladeUpDown": gdjs.BonusLevelCode.GDSawbladeUpDownObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects2Objects = Hashtable.newFrom({"Death": gdjs.BonusLevelCode.GDDeathObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects1Objects = Hashtable.newFrom({"DeathLeft": gdjs.BonusLevelCode.GDDeathLeftObjects1});
gdjs.BonusLevelCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.BonusLevelCode.GDBnuuyObjects1, gdjs.BonusLevelCode.GDBnuuyObjects2);

gdjs.BonusLevelCode.GDDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects2Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects1 */
gdjs.BonusLevelCode.GDDeathLeftObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects1Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.BonusLevelCode.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SawbladeUpDown"), gdjs.BonusLevelCode.GDSawbladeUpDownObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeUpDownObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeUpDownObjects2[i].rotate(360, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeUpDown"), gdjs.BonusLevelCode.GDSawbladeUpDownObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects, gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSawbladeUpDownObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects = Hashtable.newFrom({"Bnuuy": gdjs.BonusLevelCode.GDBnuuyObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSawbladeLeftRightObjects1Objects = Hashtable.newFrom({"SawbladeLeftRight": gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects2Objects = Hashtable.newFrom({"Death": gdjs.BonusLevelCode.GDDeathObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects1Objects = Hashtable.newFrom({"DeathLeft": gdjs.BonusLevelCode.GDDeathLeftObjects1});
gdjs.BonusLevelCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.BonusLevelCode.GDBnuuyObjects1, gdjs.BonusLevelCode.GDBnuuyObjects2);

gdjs.BonusLevelCode.GDDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects2Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects1 */
gdjs.BonusLevelCode.GDDeathLeftObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects1Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects1[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects1.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects1[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.15, 0.15, 0.15, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.BonusLevelCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SawbladeLeftRight"), gdjs.BonusLevelCode.GDSawbladeLeftRightObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDSawbladeLeftRightObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDSawbladeLeftRightObjects2[i].rotate(360, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SawbladeLeftRight"), gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects, gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDSawbladeLeftRightObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects2Objects = Hashtable.newFrom({"Bnuuy": gdjs.BonusLevelCode.GDBnuuyObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDFoxObjects2Objects = Hashtable.newFrom({"Fox": gdjs.BonusLevelCode.GDFoxObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects3Objects = Hashtable.newFrom({"Death": gdjs.BonusLevelCode.GDDeathObjects3});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects2Objects = Hashtable.newFrom({"DeathLeft": gdjs.BonusLevelCode.GDDeathLeftObjects2});
gdjs.BonusLevelCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Right";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.BonusLevelCode.GDBnuuyObjects2, gdjs.BonusLevelCode.GDBnuuyObjects3);

gdjs.BonusLevelCode.GDDeathObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathObjects3Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects3[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathObjects3[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects3.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects3[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("Bruh")) == "Left";
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects2 */
gdjs.BonusLevelCode.GDDeathLeftObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDeathLeftObjects2Objects, (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterXInScene()), (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getCenterYInScene()), "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "95fe7f6a064b3e17dce2774ad92cee83f877d2d6dda1cd16d79b876ca572911c_Death.aac", false, 100, 1 + gdjs.randomFloatInRange(0.8, 1.2));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects2[i].getBehavior("Tween").addObjectOpacityTween("DedOp", 0, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDeathLeftObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDeathLeftObjects2[i].getBehavior("Tween").addObjectPositionYTween("DedY", (( gdjs.BonusLevelCode.GDBnuuyObjects2.length === 0 ) ? 0 :gdjs.BonusLevelCode.GDBnuuyObjects2[0].getPointY("")) - 15, "easeInOutQuad", 800, false);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.BonusLevelCode.asyncCallback17099228 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects3);
{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects3[i].rotateTowardAngle(10, 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects3.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects3[i].returnVariable(gdjs.BonusLevelCode.GDFoxObjects3[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(3);
}}
gdjs.BonusLevelCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17099228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.asyncCallback17100428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects2[i].returnVariable(gdjs.BonusLevelCode.GDFoxObjects2[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(2);
}}
gdjs.BonusLevelCode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BonusLevelCode.asyncCallback17100428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BonusLevelCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDFoxObjects2.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDFoxObjects2[i].getBehavior("RectangleMovement").IsOnRight((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDFoxObjects2[k] = gdjs.BonusLevelCode.GDFoxObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDFoxObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDFoxObjects2 */
{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDFoxObjects2.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDFoxObjects2[i].getBehavior("RectangleMovement").IsOnLeft((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDFoxObjects2[k] = gdjs.BonusLevelCode.GDFoxObjects2[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDFoxObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDFoxObjects2 */
{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects2Objects, gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDFoxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList25(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RunTweenFox")) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fox"), gdjs.BonusLevelCode.GDFoxObjects2);
{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects2[i].rotateTowardAngle(-(10), 300, runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDFoxObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDFoxObjects2[i].returnVariable(gdjs.BonusLevelCode.GDFoxObjects2[i].getVariables().getFromIndex(0)).setNumber(-(10));
}
}{runtimeScene.getGame().getVariables().get("RunTweenFox").setNumber(2);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RunTweenFox")) == 2;
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList26(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("RunTweenFox")) == 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.BonusLevelCode.eventsList27(runtimeScene);} //End of subevents
}

}


};gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects2Objects = Hashtable.newFrom({"Bnuuy": gdjs.BonusLevelCode.GDBnuuyObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDoubleOrbObjects2Objects = Hashtable.newFrom({"DoubleOrb": gdjs.BonusLevelCode.GDDoubleOrbObjects2});
gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDoubleOrbObjects1Objects = Hashtable.newFrom({"DoubleOrb": gdjs.BonusLevelCode.GDDoubleOrbObjects1});
gdjs.BonusLevelCode.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects2);
gdjs.copyArray(runtimeScene.getObjects("DoubleOrb"), gdjs.BonusLevelCode.GDDoubleOrbObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects2Objects, gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDoubleOrbObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDBnuuyObjects2 */
/* Reuse gdjs.BonusLevelCode.GDDoubleOrbObjects2 */
gdjs.copyArray(runtimeScene.getObjects("OrbSpawner"), gdjs.BonusLevelCode.GDOrbSpawnerObjects2);
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.5, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(1, 5, 5, 5, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDBnuuyObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDBnuuyObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDDoubleOrbObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDoubleOrbObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.BonusLevelCode.GDOrbSpawnerObjects2.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDOrbSpawnerObjects2[i].resetTimer("Respawn");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("OrbSpawner"), gdjs.BonusLevelCode.GDOrbSpawnerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.BonusLevelCode.GDOrbSpawnerObjects1.length;i<l;++i) {
    if ( gdjs.BonusLevelCode.GDOrbSpawnerObjects1[i].getTimerElapsedTimeInSecondsOrNaN("Respawn") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.BonusLevelCode.GDOrbSpawnerObjects1[k] = gdjs.BonusLevelCode.GDOrbSpawnerObjects1[i];
        ++k;
    }
}
gdjs.BonusLevelCode.GDOrbSpawnerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DoubleOrb"), gdjs.BonusLevelCode.GDDoubleOrbObjects1);
{for(var i = 0, len = gdjs.BonusLevelCode.GDDoubleOrbObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDDoubleOrbObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDDoubleOrbObjects1Objects, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)), "");
}}

}


};gdjs.BonusLevelCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bnuuy"), gdjs.BonusLevelCode.GDBnuuyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carrot"), gdjs.BonusLevelCode.GDCarrotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDBnuuyObjects1Objects, gdjs.BonusLevelCode.mapOfGDgdjs_9546BonusLevelCode_9546GDCarrotObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.BonusLevelCode.GDCarrotObjects1 */
{for(var i = 0, len = gdjs.BonusLevelCode.GDCarrotObjects1.length ;i < len;++i) {
    gdjs.BonusLevelCode.GDCarrotObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-bonus-earned-in-video-game-2058.wav", false, 50, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ending", false);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(608);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(616);
}}

}


{



}


{


gdjs.BonusLevelCode.eventsList0(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList16(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList17(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList18(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList20(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList22(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList24(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList28(runtimeScene);
}


{


gdjs.BonusLevelCode.eventsList29(runtimeScene);
}


};

gdjs.BonusLevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BonusLevelCode.GDThanksObjects1.length = 0;
gdjs.BonusLevelCode.GDThanksObjects2.length = 0;
gdjs.BonusLevelCode.GDThanksObjects3.length = 0;
gdjs.BonusLevelCode.GDThanksObjects4.length = 0;
gdjs.BonusLevelCode.GDThanksObjects5.length = 0;
gdjs.BonusLevelCode.GDThanksObjects6.length = 0;
gdjs.BonusLevelCode.GDThanksObjects7.length = 0;
gdjs.BonusLevelCode.GDThanksObjects8.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects1.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects2.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects3.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects4.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects5.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects6.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects7.length = 0;
gdjs.BonusLevelCode.GDBnuuyObjects8.length = 0;
gdjs.BonusLevelCode.GDseaObjects1.length = 0;
gdjs.BonusLevelCode.GDseaObjects2.length = 0;
gdjs.BonusLevelCode.GDseaObjects3.length = 0;
gdjs.BonusLevelCode.GDseaObjects4.length = 0;
gdjs.BonusLevelCode.GDseaObjects5.length = 0;
gdjs.BonusLevelCode.GDseaObjects6.length = 0;
gdjs.BonusLevelCode.GDseaObjects7.length = 0;
gdjs.BonusLevelCode.GDseaObjects8.length = 0;
gdjs.BonusLevelCode.GDGrassObjects1.length = 0;
gdjs.BonusLevelCode.GDGrassObjects2.length = 0;
gdjs.BonusLevelCode.GDGrassObjects3.length = 0;
gdjs.BonusLevelCode.GDGrassObjects4.length = 0;
gdjs.BonusLevelCode.GDGrassObjects5.length = 0;
gdjs.BonusLevelCode.GDGrassObjects6.length = 0;
gdjs.BonusLevelCode.GDGrassObjects7.length = 0;
gdjs.BonusLevelCode.GDGrassObjects8.length = 0;
gdjs.BonusLevelCode.GDDirtObjects1.length = 0;
gdjs.BonusLevelCode.GDDirtObjects2.length = 0;
gdjs.BonusLevelCode.GDDirtObjects3.length = 0;
gdjs.BonusLevelCode.GDDirtObjects4.length = 0;
gdjs.BonusLevelCode.GDDirtObjects5.length = 0;
gdjs.BonusLevelCode.GDDirtObjects6.length = 0;
gdjs.BonusLevelCode.GDDirtObjects7.length = 0;
gdjs.BonusLevelCode.GDDirtObjects8.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects1.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects2.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects3.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects4.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects5.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects6.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects7.length = 0;
gdjs.BonusLevelCode.GDInvisWallObjects8.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects1.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects2.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects3.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects4.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects5.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects6.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects7.length = 0;
gdjs.BonusLevelCode.GDInvisWall2Objects8.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects1.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects2.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects3.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects4.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects5.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects6.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects7.length = 0;
gdjs.BonusLevelCode.GDDashParticleObjects8.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects1.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects2.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects3.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects4.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects5.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects6.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects7.length = 0;
gdjs.BonusLevelCode.GDLandParticlesObjects8.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects1.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects2.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects3.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects4.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects5.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects6.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects7.length = 0;
gdjs.BonusLevelCode.GDLandParticles3Objects8.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects1.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects2.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects3.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects4.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects5.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects6.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects7.length = 0;
gdjs.BonusLevelCode.GDLandParticles2Objects8.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects1.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects2.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects3.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects4.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects5.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects6.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects7.length = 0;
gdjs.BonusLevelCode.GDCarrotObjects8.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects1.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects2.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects3.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects4.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects5.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects6.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects7.length = 0;
gdjs.BonusLevelCode.GDSadBNUUYObjects8.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects1.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects2.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects3.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects4.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects5.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects6.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects7.length = 0;
gdjs.BonusLevelCode.GDDebuggerTextObjects8.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects1.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects2.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects3.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects4.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects5.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects6.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects7.length = 0;
gdjs.BonusLevelCode.GDBnuuyDashAfterLeftObjects8.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects1.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects2.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects3.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects4.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects5.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects6.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects7.length = 0;
gdjs.BonusLevelCode.GDLandParticles4Objects8.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects1.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects2.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects3.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects4.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects5.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects6.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects7.length = 0;
gdjs.BonusLevelCode.GDSawbladeObjects8.length = 0;
gdjs.BonusLevelCode.GDDeathObjects1.length = 0;
gdjs.BonusLevelCode.GDDeathObjects2.length = 0;
gdjs.BonusLevelCode.GDDeathObjects3.length = 0;
gdjs.BonusLevelCode.GDDeathObjects4.length = 0;
gdjs.BonusLevelCode.GDDeathObjects5.length = 0;
gdjs.BonusLevelCode.GDDeathObjects6.length = 0;
gdjs.BonusLevelCode.GDDeathObjects7.length = 0;
gdjs.BonusLevelCode.GDDeathObjects8.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects1.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects2.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects3.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects4.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects5.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects6.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects7.length = 0;
gdjs.BonusLevelCode.GDDeathLeftObjects8.length = 0;
gdjs.BonusLevelCode.GDFoxObjects1.length = 0;
gdjs.BonusLevelCode.GDFoxObjects2.length = 0;
gdjs.BonusLevelCode.GDFoxObjects3.length = 0;
gdjs.BonusLevelCode.GDFoxObjects4.length = 0;
gdjs.BonusLevelCode.GDFoxObjects5.length = 0;
gdjs.BonusLevelCode.GDFoxObjects6.length = 0;
gdjs.BonusLevelCode.GDFoxObjects7.length = 0;
gdjs.BonusLevelCode.GDFoxObjects8.length = 0;
gdjs.BonusLevelCode.GDOrbObjects1.length = 0;
gdjs.BonusLevelCode.GDOrbObjects2.length = 0;
gdjs.BonusLevelCode.GDOrbObjects3.length = 0;
gdjs.BonusLevelCode.GDOrbObjects4.length = 0;
gdjs.BonusLevelCode.GDOrbObjects5.length = 0;
gdjs.BonusLevelCode.GDOrbObjects6.length = 0;
gdjs.BonusLevelCode.GDOrbObjects7.length = 0;
gdjs.BonusLevelCode.GDOrbObjects8.length = 0;
gdjs.BonusLevelCode.GDArrowObjects1.length = 0;
gdjs.BonusLevelCode.GDArrowObjects2.length = 0;
gdjs.BonusLevelCode.GDArrowObjects3.length = 0;
gdjs.BonusLevelCode.GDArrowObjects4.length = 0;
gdjs.BonusLevelCode.GDArrowObjects5.length = 0;
gdjs.BonusLevelCode.GDArrowObjects6.length = 0;
gdjs.BonusLevelCode.GDArrowObjects7.length = 0;
gdjs.BonusLevelCode.GDArrowObjects8.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects1.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects2.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects3.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects4.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects5.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects6.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects7.length = 0;
gdjs.BonusLevelCode.GDDirtHalfObjects8.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects1.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects2.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects3.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects4.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects5.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects6.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects7.length = 0;
gdjs.BonusLevelCode.GDSawbladeUpDownObjects8.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects1.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects2.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects3.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects4.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects5.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects6.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects7.length = 0;
gdjs.BonusLevelCode.GDSawbladeLeftRightObjects8.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects1.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects2.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects3.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects4.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects5.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects6.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects7.length = 0;
gdjs.BonusLevelCode.GDJumpthruObjects8.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects1.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects2.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects3.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects4.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects5.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects6.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects7.length = 0;
gdjs.BonusLevelCode.GDDoubleOrbObjects8.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects1.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects2.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects3.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects4.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects5.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects6.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects7.length = 0;
gdjs.BonusLevelCode.GDOrbSpawnerObjects8.length = 0;

gdjs.BonusLevelCode.eventsList30(runtimeScene);

return;

}

gdjs['BonusLevelCode'] = gdjs.BonusLevelCode;
